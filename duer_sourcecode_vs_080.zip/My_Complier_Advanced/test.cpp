#include <Windows.h>
#include <iostream>
#include <fstream>
#include <memory>
#include "lexical_analyzer.h"
#include "syntactic_analyzer.h"
#include "lang_type_convert.h"
using std::cout;
using std::endl;
using std::cin;

int main() {
	system("title Duer builder 0.80");
	deq<token_t> all_the_tokens;
	try {
		std::ifstream ifs("d://1.txt");
		if(!ifs.is_open())
			ifs.open("1.txt");
		syntatic_analyzer sa;
		lexical_analyzer la(ifs);
		//int i = -1;
		while (1) {
			token_t token = *la.get_token();
			if (token.kind != COMMENT_TOKEN
				&& token.kind != END_OF_LINE_TOKEN) {
				all_the_tokens.emplace_back(token);
			}
			if (token.kind == END_OF_FILE_TOKEN) break;
		}
		lang_runner lr(Move(all_the_tokens),&sa);
		sa.prun_env = &lr;
		lr.go();
	}
	catch (_STD exception &e) {
		cout << e.what();
	}
	system("pause");
}
#pragma once
#include <cctype>
struct char_disposer {
	inline bool is_name_beginning(char ch) {
		if (isalpha(ch) || ch == '_') return true;
		else return false;
	}
	inline bool is_name_body(char ch) {
		if (isalnum(ch) || ch == '_') return true;
		else return false;
	}
	inline char special_char_get(char ch) {
		switch (ch)
		{
		case 'n':
			return '\n';
		case 't':
			return '\t';
		case '0':
			return 0;
		default:
			return ch;
		}
	}
};
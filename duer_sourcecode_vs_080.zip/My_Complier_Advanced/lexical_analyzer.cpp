#include "lexical_analyzer.h"
void lexical_analyzer::_Initial_map_of_name()
{
	map_of_inside_names["new"] = NEW_TOKEN;
	map_of_inside_names["ref"] = REF_TOKEN;
	map_of_inside_names["import"] = IMPORT_TOKEN;
	map_of_inside_names["break"] = BREAK_TOKEN;
	map_of_inside_names["continue"] = CONTINUE_TOKEN;
	map_of_inside_names["struct"] = STRUCT_TOKEN;
	map_of_inside_names["if"] = IF_TOKEN;
	map_of_inside_names["elif"] = ELIF_TOKEN;
	map_of_inside_names["while"] = WHILE_TOKEN;
	map_of_inside_names["for"] = FOR_TOKEN;
	map_of_inside_names["else"] = ELSE_TOKEN;
	map_of_inside_names["int"] = INT_TOKEN;
	map_of_inside_names["double"] = DOUBLE_TOKEN;
	map_of_inside_names["bool"] = BOOL_TOKEN;
	map_of_inside_names["char"] = CHAR_TOKEN;
	map_of_inside_names["void"] = VOID_TOKEN;
	map_of_inside_names["const"] = CONST_TOKEN;
	map_of_inside_names["static"] = STATIC_TOKEN;
	map_of_inside_names["string"] = STRING_TOKEN;
	map_of_inside_names["return"] = RETURN_TOKEN;
	map_of_inside_names["require_once"] = INCLUDE_ONCE_TOKEN;
	map_of_inside_names["require"] = INCLUDE_TOKEN;
	map_of_inside_names["class"] = CLASS_TOKEN;
	map_of_inside_names["struct"] = STRUCT_TOKEN;
	map_of_inside_names["typedef"] = TYPEDEF_TOKEN;
	map_of_inside_names["_SYSTEM_BUILTIN_PAUSE"] = PAUSE_TOKEN;
	map_of_inside_names["_SYSTEM_BUILTIN_CLEAR"] = CLEAR_TOKEN;
	map_of_inside_names["_SYSTEM_BUILTIN_PRINTOUT_STD"] = PRINT_OUT_TOKEN;
	map_of_inside_names["_SYSTEM_BUILTIN_SCANIN_STD"] = SCAN_IN_TOKEN;
	map_of_inside_names["_SYSTEM_BUILTIN_SCANIN_CHAR_STD"] = SCAN_IN_CHAR_TOKEN;
	map_of_inside_names["_SYSTEM_BUILTIN_SCANIN_LINE_STD"] = SCAN_IN_LINE_TOKEN;
	map_of_inside_names["_SYSTEM_BUILTIN_EXIT"] = EXIT_TOKEN;
}
void lexical_analyzer::_Initial_deq_of_sym()
{	//initial list of sym
	deq_of_sym.emplace_back("(", LEFT_PAREN_TOKEN);
	deq_of_sym.emplace_back(")", RIGHT_PAREN_TOKEN);
	deq_of_sym.emplace_back("{", LEFT_BRACE_TOKEN);
	deq_of_sym.emplace_back("}", RIGHT_BRACE_TOKEN);
	deq_of_sym.emplace_back("[", LEFT_BRACKET_TOKEN);
	deq_of_sym.emplace_back("]", RIGHT_BRACKET_TOKEN);
	deq_of_sym.emplace_back("/*", LEFT_COMMENT_TOKEN);
	deq_of_sym.emplace_back("*/", RIGHT_COMMENT_TOKEN);
	deq_of_sym.emplace_back("||", C_OR_OPERATOR_TOKEN);
	deq_of_sym.emplace_back("&&", C_AND_OPERATOR_TOKEN);
	deq_of_sym.emplace_back("++", INCR_OPERATOR_TOKEN);
	deq_of_sym.emplace_back("--", DECR_OPERATOR_TOKEN);
	deq_of_sym.emplace_back("!=", NOT_EQUAL_TOKEN);
	deq_of_sym.emplace_back("==", EQUAL_TOKEN);
	deq_of_sym.emplace_back("::", GLOBAL_TOKEN);
	deq_of_sym.emplace_back(">=", HE_TOKEN);
	deq_of_sym.emplace_back("<=", LE_TOKEN);
	deq_of_sym.emplace_back("|", B_OR_OPERATOR_TOKEN);
	deq_of_sym.emplace_back("&", B_AND_OPERATOR_TOKEN);
	deq_of_sym.emplace_back("!", NOT_OPERATOR_TOKEN);
	deq_of_sym.emplace_back(".", DOT_TOKEN);
	deq_of_sym.emplace_back(",", COMMA_TOKEN);
	deq_of_sym.emplace_back("^", POW_OPERATOR_TOKEN);
	deq_of_sym.emplace_back("+", ADD_OPERATOR_TOKEN);
	deq_of_sym.emplace_back("-", SUB_OPERATOR_TOKEN);
	deq_of_sym.emplace_back("*", MUL_OPERATOR_TOKEN);
	deq_of_sym.emplace_back("/", DIV_OPERATOR_TOKEN);
	deq_of_sym.emplace_back("=", ASSIGN_OPERATOR_TOKEN);
	deq_of_sym.emplace_back(">", HIGHER_TOKEN);
	deq_of_sym.emplace_back("<", LOWER_TOKEN);
	deq_of_sym.emplace_back(";", SEMI_TOKEN);
}
token_type_t lexical_analyzer::_Scan_sym(char ch)
{	//check if ch is a sym, peek one more character
	_STD stringstream ss;
	ss << ch << static_cast<char>(is->peek());
	try {
		_STD for_each(deq_of_sym.cbegin(),
			deq_of_sym.cend(), [=, &ss](sym_pair_t &sym_pair)->void {
			if (sym_pair.first == ss.str()) {
				ptoken->str += is->get();
				throw sym_pair.second;
			}
			if (sym_pair.first == ss.str().substr(0,1))
				throw sym_pair.second;
		});
	}
	catch (token_type_t &stat) {
		return stat;
	}
	return BAD_TOKEN;
}
void lexical_analyzer::_Move_on()
{	//move on
	ptoken = allocate_sh<token_t>();
	size_type out_pos = 0;
	lexer_status_t status = INITIAL_STATUS;
	char current_char;

	ptoken->kind = BAD_TOKEN;

	while (!(is->eof() && is->bad()))
	{
		current_char = is->peek();
		if ((status == IN_INT_PART_STATUS || status == IN_FRAC_PART_STATUS)
			&& !isdigit(current_char)
			&& current_char != '.')
		{	//get a double number and return
			ptoken->kind = (status == IN_FRAC_PART_STATUS) ? DD_NUMBER_TOKEN : INT_NUMBER_TOKEN;
			_STD stringstream sstr(ptoken->str);
			if (ptoken->kind == DD_NUMBER_TOKEN)
				sstr >> (ptoken->value.dd_v);
			else
				sstr >> (ptoken->value.int_v);
			return;
		}
		if (status == IN_NAME_STATUS && !_cd.is_name_body(current_char))
		{	//GET A NAME STRING
			try {
				ptoken->kind = map_of_inside_names.at(ptoken->str);
			} catch (_STD exception &) {
				ptoken->kind = NAME_TOKEN;
			}
			return;
		}
		is->get();

		if (status == IN_NAME_STATUS && _cd.is_name_body(current_char))
		{	//get a name
			ptoken->str += current_char;
			continue;
		}

		if (status == INITIAL_STATUS) 
		{
			if (_cd.is_name_beginning(current_char)) 
			{	//���ֿ�ʼ
				ptoken->str += current_char;
				status = IN_NAME_STATUS;
				continue;
			}
			else if (current_char == '\'') {
				int next = is->get();
				if (next == '\\') 
					next = _cd.special_char_get(is->get());
				if (is->get() != '\'')
						_Syntax_error();
				ptoken->kind = CHAR_NUMBER_TOKEN;
				ptoken->value.int_v = next;
				return;
			}
			else if (current_char == '/' && is->peek() == '*')
			{
				is->get();
				ptoken->kind = COMMENT_TOKEN;
				while (1) {
					if ((current_char=is->get()) == '*')
						if ((current_char = is->get()) == '/')
							return;
				}
			}
			else if (current_char == '"')
			{	//�ַ�����ʼ
				status = IN_STR_STATUS;
				continue;
			}
			else if (current_char == '/' && is->peek() == '/')
			{
				string s;
				ptoken->kind = COMMENT_TOKEN;
				_STD getline(*is, s);
				return;
			}
		}

		if (status == IN_STR_STATUS)
		{
			switch (current_char)
			{
			case '\\':
				ptoken->str += _cd.special_char_get(is->get());
				break;
			case EOF:
				_Syntax_error(Err_no_t::STRING_LONELY_QUO);
				break;
			case '"':
				ptoken->kind = STRING_NUMBER_TOKEN;
				return;
			default:
				ptoken->str += current_char;
				break;
			}
			continue;
		}


		if (_Check_if(current_char, EOF, END_OF_FILE_TOKEN)) return;
		if (isspace(current_char))
		{	//confronting space
			if (current_char == '\n')
			{
				ptoken->kind = END_OF_LINE_TOKEN;
				return;
			}
			continue;
		}
		ptoken->str += current_char;

		if (current_char == '.')
		{
			if (status == IN_INT_PART_STATUS) {
				status = DOT_STATUS;
				continue;
			}
			//else if(status == INITIAL_STATUS)
			//	_Syntax_error(Err_no_t::WHY_DOT_HERE);
		}

		if ((ptoken->kind = _Scan_sym(current_char)) != BAD_TOKEN)
			return;
		else if (isdigit(current_char))
		{
			if (status == INITIAL_STATUS)
				status = IN_INT_PART_STATUS;
			else if (status == DOT_STATUS)
				status = IN_FRAC_PART_STATUS;
		}
		else
			_Bad_char(current_char);
	}
}
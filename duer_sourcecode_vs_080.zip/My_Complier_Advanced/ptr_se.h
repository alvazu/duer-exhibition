#pragma once

/*smart_ptr build 2016 rebuild in 201706

	just sh_ptr & uni_ptr
	if you prapare to use dynamic type, make sure that you have set your destruction function in a right state
	provide allocate_sh() & allocate_uni() ^_^

	**should be atomic, but unfortunately not, so avoid using it in multi-thread development

* Powered by Alvazu,
* Consult your license regarding permissions and restrictions.
* Ver 0.6.2
*/
#pragma once
extern "C" {
#include <stdlib.h>
}
#include <iostream>
#include "Type_converts.h"
#include "alloc.h"
#include <functional>
#pragma push_macro("new")
#undef new
class shptr_counter {
	//counter for sh_ptr
private:
	using count_type = size_t;
	count_type get_count() const
	{ //to get the counter of using
		return cnt ? *cnt : 0;
	}
	shptr_counter() = default;
	explicit shptr_counter(count_type cn)
	{ //construct by OUNTER
		set_count(cn);
	}
	explicit shptr_counter(const shptr_counter & cn)
	{ //construct by SH_COUNTER
		cnt = cn.cnt;
	}
	~shptr_counter()
	{
		if (cnt && *cnt == 0) free(cnt);
	}

	void set_count(count_type pt)
	{//set the counter
		check_and_malloc();
		*cnt = pt;
	}
	shptr_counter& operator=(count_type c)
	{//set the counter
		set_count(c);
		return *this;
	}
	shptr_counter& operator=(const shptr_counter& c)
	{//set the counter and SHARE the space
		cnt = c.cnt;
		return *this;
	}
	bool zero() const
	{ //clear counter
		return get_count() == 0;
	}
	operator count_type() const
	{ //get counter
		return get_count();
	}
	operator bool() const
	{ //check if zero
		return !zero();
	}
private:

	const shptr_counter& operator++()
	{	//front add
		if (check_and_malloc()) *cnt = 1;
		else ++*cnt;
		return *this;
	}
	const shptr_counter& operator--()
	{	//front sub
		if (check_and_malloc()) *cnt = 0;
		else --*cnt;
		if (*cnt < 0) *cnt = 0;
		return *this;
	}
	void __reset_cnt_ptr()
	{		//clear but not free
		cnt = nullptr;
	}

private:
	bool check_and_malloc()
	{	//if not have space, malloc it
		if (!cnt) {
			cnt = (count_type *)malloc(sizeof(count_type));
			return true;
		}
		return false;
	}
	count_type *cnt = nullptr;

	template<typename _Ty> friend class sh_ptr;
	template<typename _Ty> friend class uni_ptr;
	friend inline bool operator==(const shptr_counter &_L,
		const shptr_counter &_R);
	friend inline bool operator==(const shptr_counter &_L,
		count_type cnt);
};
inline bool operator==(const shptr_counter &_L,
	const shptr_counter &_R)
{	//check if equal
	return _L.get_count() == _R.get_count();
}
inline bool operator==(const shptr_counter &_L,
	typename shptr_counter::count_type cnt)
{	//check if equal
	return _L.get_count() == cnt;
}
//use custom deleter, you need to create a destruction function hand-actuated
//**might cause memory leak, use it for develop if you know how to control it
template <typename _Ty> class _deleter {
	using pointer = _Ty *;
public:
	using deleter_type = _STD function<void(pointer)>;
	_deleter() = default;
	_deleter(const _deleter &dl)
		:_Dl(dl._Dl)
	{	//construct by deleter
	}

	_deleter(deleter_type dl)
		:_Dl(nullptr)
	{	//construct by deleter
		set_deleter(dl);
	}

	_deleter(deleter_type *dl)
	{ //construct by ptr of deleter
		_Dl = dl;
	}

	_deleter(_STD nullptr_t)
	{  //construct by nullptr
		_Dl = new deleter_type;
		*_Dl = nullptr;
	}

	bool is_default_deleter() const
	{ //check if using default deleter(::delete)
		return _Dl && !*_Dl;
	}

	void set_deleter(deleter_type dl)&
	{ //set custom deleter by deleter
		if (!_Dl) _Dl = new deleter_type(dl);
		*_Dl = dl;
	}

	void set_deleter(deleter_type *p)&
	{//set custom deleter by ptr of deleter
		_Dl = p;
	}

	void reset_deleter()
	{ //clear deleter and free space
		delete _Dl;
		_Dl = nullptr;
	}
protected:
	deleter_type &get_del() const
	{ //get deleter and use it directly
		return *_Dl;
	}
	deleter_type *_Dl;
};

//provide base for each smart pointer
template <typename _Ty> class _ptr_base {
	static_assert(!is_arr<_Ty>(), "custom smart ptr error: array version not finished yet.");
	using pointer = _Ty *;
	using reference = _Ty &;

public:
	reference operator*() const
	{ //get itself
		return *_Pt;
	}

	pointer operator->() const
	{ //get the pointer
		return &this->operator*();
	}

	pointer get() const
	{	//get the pointer itself, DANGEROUS
		return _Pt;
	}

	virtual bool available() const
	{ //check if ptr is available
		return _Pt != nullptr;
	}

	operator bool()const
	{ //check if ptr is available
		return available();
	}
	//virtual void reset() = 0;
protected:
	[[noreturn]] void _dynamic_ptr_err()
	{	//dy_ptr_err happened
		throw _STD runtime_error("dynamic_ptr makes no sense");
	}
	_ptr_base(pointer p) :_Pt(p) {}
	pointer _Pt;
};
//custom shared_ptr
template <typename _Ty> class sh_ptr : public _ptr_base<_Ty> {

	using _Myt = sh_ptr<_Ty>;
	//using _Deleter = _deleter<_Ty>;
	using _Pbase = _ptr_base<_Ty>;
	using pointer = _Ty *;
	using reference = _Ty &;
	using const_reference = const _Ty &;
public:
	using count_type = typename shptr_counter::count_type;
	using element_type = _Ty;
	sh_ptr()
		:_ptr_base(nullptr), _Cn(0)//, _deleter(nullptr)
	{	//construct by nullptr
	}

	sh_ptr(_STD nullptr_t)
		:_ptr_base(nullptr), _Cn()//, _deleter(nullptr)
	{	//construct by nullptr
	}
	template <typename _T>
	explicit sh_ptr(_T *pt)
		:_ptr_base(dynamic_cast<_Ty*>(pt)), _Cn(static_cast<count_type>(1))//, _deleter(nullptr)
	{	//construct by dynamic ptr
		if (_Pt == nullptr)
			_dynamic_ptr_err();
	}


	explicit sh_ptr(pointer pt)
		:_ptr_base(pt), _Cn(static_cast<count_type>(1))//, _deleter(nullptr)
	{	//construct by explicit pointer
	}



	sh_ptr(const _Myt & sh)
		:_ptr_base(sh._Pt), _Cn(sh._Cn)//, _deleter(sh._Dl)
	{ //construct by an extant sh_ptr
		++_Cn;
	}

	sh_ptr(_Myt && sh) noexcept
		: _ptr_base(sh._Pt), _Cn(sh._Cn)//, _deleter(sh._Dl)
	{ //construct by an extant sh_ptr
		sh._Pt = nullptr;
		sh._Cn.__reset_cnt_ptr();
	}

	virtual ~sh_ptr()
	{	//leave smart ptr
		reset();
	}

	_Myt &operator=(const _Myt &sh)&
	{	//assign by sh_ptr
		if (&sh == this) return *this;
		_Myt shp = sh;
		if (!sh.available() && _Pt != nullptr)
		{
			this->_Pt = nullptr;
			return *this;
		}
			//throw _STD runtime_error("sh_ptr(_R) not available");
		if (_Pt == sh._Pt)
			return *this;
		bool rrrest = 0;
		if (available()) {
			if (!--_Cn) {	//cnt==0
				//if (is_default_deleter())
					::delete _Pt;
				//else
				//	get_del()(_Pt);
				//reset_deleter();
			}
			_Pt = nullptr;
			rrrest = true;		//deleter is right settled
		}
		else rrrest = false;
		//if (!rrrest)
			//reset_deleter();
		_Pt = shp._Pt;
		_Cn = shp._Cn;

		//set_deleter(shp._Dl);
		++_Cn;

		return *this;
	}
	_Myt &operator=(_Myt &&sh)& noexcept
	{	//assign by sh_ptr
		if (&sh == this) return *this;
		_Myt shp = sh;
		if (!sh.available()) {
			reset();
			return *this;
		}
		bool rrrest = 0;
		if (available()) {
			if (!--_Cn) {	//cnt==0
				//if (is_default_deleter())
					::delete _Pt;
				//else
				//	get_del()(_Pt);
				//reset_deleter();
			}
			_Pt = nullptr;
			rrrest = true;		//deleter is right settled
		}
		else rrrest = false;
		//if (!rrrest)
		//	reset_deleter();
		_Pt = shp._Pt;
		_Cn = shp._Cn;
		//set_deleter(shp._Dl);
		shp._Pt = nullptr;
		shp._Cn.__reset_cnt_ptr();
		return *this;
	}
	_Myt &operator=(_STD nullptr_t)&
	{	//assign by nullptr
		reset();
		return *this;
	}
public:

	bool unique() const
	{ //check if unique
		return available() ? _Cn == static_cast<count_type>(1) : false;
	}
	typename count_type use_count() const
	{ //get use count
		return available() ? _Cn : 0;
	}
	void reset(pointer p)
	{ //reset smart ptr
		operator=(p);
	}
	void reset(const _Myt &sh)
	{ //reset smart ptr
		operator=(sh);
	}
	void reset(_Myt &&sh)
	{ //reset smart ptr
		operator=(Move(sh));
	}
	template <typename _T>
	void reset(_T *pt)
	{	//reset by dynamic ptr
		pointer p = dynamic_cast<_Ty*>(pt);
		if (!p)
			_dynamic_ptr_err();
		else
			operator=(p);
	}
	bool reset() &
	{ //special reset() which avoids _deleter's memory leak
		if (available()) {
			if (!--_Cn) {	//cnt==0
				//if (is_default_deleter())
					::delete _Pt;
				//else
				//	get_del()(_Pt);
				//reset_deleter();
			}
			_Pt = nullptr;
			return true;		//deleter is right settled
		}
		return false;
	}
private:
	_Myt &operator=(pointer p)& noexcept
	{
		reset();
		_Cn.__reset_cnt_ptr();
		_Cn = static_cast<count_type>(1);
		_Pt = p;
	}
	shptr_counter _Cn;
};

//allocate shared ptr
template <typename _Ty,
	class ... _types>
	sh_ptr<_Ty> allocate_sh(_types &&..._val)
{	//allocate sh_ptr by constructors
	Allocator<_Ty> alloc;
	_Ty *ptr = alloc.allocate(1);
	alloc.construct(ptr, Forward<_types>(_val)...);
	sh_ptr<_Ty> ret(ptr);
	return ret;
}

//provide symbols for ptr
template <typename _Ty> inline
bool operator==(const _ptr_base<_Ty> &_L,
	const _ptr_base<_Ty> &_R)
{
	return _L.get() == _R.get();
}
template <typename _Ty> inline
bool operator!=(const _ptr_base<_Ty> &_L,
	const _ptr_base<_Ty> &_R)
{
	return _L.get() != _R.get();
}
template <typename _Ty> inline
size_t operator-(const _ptr_base<_Ty> &_L,
	const _ptr_base<_Ty> &_R)
{
	return _L.get() - _R.get();
}


template <typename _Ty> inline
_STD ostream & operator<<(_STD ostream& os, const ::_ptr_base<_Ty> &p)
{	//provide output/input for ptr
	os << *p;
	return os;
}
template <typename _Ty> inline
_STD istream & operator>>(_STD istream& is, const ::_ptr_base<_Ty> &p)
{	//provide output/input for ptr
	is >> *p;
	return is;
}

//custom unique_ptr
template <typename _Ty> class uni_ptr : public _deleter<_Ty>, public _ptr_base<_Ty> {
	using _Myt = uni_ptr<_Ty>;
	using pointer = _Ty *;
	using reference = _Ty &;
	using const_reference = const _Ty &;
public:
	using element_type = _Ty;
	using count_type = typename shptr_counter::count_type;

	template <typename _T> uni_ptr(_T *pt)
		:_ptr_base(dynamic_cast<_Ty*>(pt)), _deleter(nullptr)
	{	//construct by dynamic ptr
		if (_Pt == nullptr)
			_dynamic_ptr_err();
	}
	template <typename _T> explicit uni_ptr(_T *pt, typename _deleter::deleter_type dl)
		:_ptr_base(dynamic_cast<_Ty*>(pt)), _deleter(dl)
	{	//construct by dynamic ptr
		if (_Pt == nullptr)
			_dynamic_ptr_err();
	}
	explicit uni_ptr(pointer p)
		:_ptr_base(p), _deleter(nullptr)
	{	//construct by a pointer
	}
	uni_ptr(const _Myt &) = delete;
	uni_ptr(_Myt && up) {
		_Pt = up._Pt;
		up._Pt = nullptr;
		_Dl = up._Dl;
		up._Dl = nullptr;
	}
	uni_ptr(pointer p, typename _deleter::deleter_type dl) :_ptr_base(p), _deleter(dl)
	{	//construct by a pointer and a deleter
	}
	_Myt &operator=(_STD nullptr_t)
	{ //construct by nullptr
		reset();
		return *this;
	}
	_Myt &operator=(_Myt && up)
	{ //construct by up&&
		reset();
		_Pt = up._Pt;
		up._Pt = nullptr;
		_Dl = up._Dl;
		up._Dl = nullptr;
		return *this;
	}
	_Myt &operator=(const _Myt &) = delete;
	pointer release()
	{	//Dangerous, return and give up pointer but not free
		pointer tmp = _Pt;
		_Pt = nullptr;
		return tmp;
	}
	virtual ~uni_ptr()
	{ //free smart ptr
		reset();
	}
	void reset(pointer p)
	{ //reset smart prt
		operator=(p);
	}
	void reset() &
	{ //reset smart prt
		if (available()) {
			if (is_default_deleter())
				delete _Pt;
			else
				get_del()(_Pt);
			_Pt = nullptr;
		}
		reset_deleter();
	}
	template <typename _T>
	void reset(_T *pt)
	{	//reset by dynamic ptr
		pointer p = dynamic_cast<_Ty*>(pt);
		if (!p)
			_dynamic_ptr_err();
		else
			operator=(p);
	}
private:
	_Myt& operator=(pointer p)
	{
		reset();
		_Pt = p;
	}
};
template <typename _Ty, class ... _types>
uni_ptr<_Ty> allocate_uni(_types &&..._val)
{	//allocate uni_ptr by constructors
	Allocator<_Ty> alloc;
	_Ty *ptr = alloc.allocate(1);
	alloc.construct(ptr, Forward<_types>(_val)...);
	uni_ptr<_Ty> ret(ptr);
	return ret;
}
#pragma pop_macro("new")
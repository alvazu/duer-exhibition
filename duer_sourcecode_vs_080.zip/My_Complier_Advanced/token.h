#pragma once
#ifndef TOKEN_H
#define TOKEN_H
#include <string>
//#include "lang_run.h"
//#include "base_var.h"
#include "deq.h"
using std::string;
typedef enum {
	BAD_TOKEN,
	VOID_TOKEN,
	GLOBAL_TOKEN,
	NEW_TOKEN,
	//keywords
	IF_TOKEN,
	ELSE_TOKEN,
	ELIF_TOKEN,
	FOR_TOKEN,
	WHILE_TOKEN,
	IMPORT_TOKEN,
	RETURN_TOKEN,
	//...
	NAME_TOKEN,
	FUNCTION_TOKEN,
	REF_TOKEN,
	//numbers
	STRING_NUMBER_TOKEN,
	DD_NUMBER_TOKEN,	//double type
	INT_NUMBER_TOKEN,	//int type
	CHAR_NUMBER_TOKEN,
	BOOL_NUMBER_TOKEN,
	//PARENS_OR_B
	LEFT_PAREN_TOKEN,
	RIGHT_PAREN_TOKEN,
	LEFT_BRACE_TOKEN,
	RIGHT_BRACE_TOKEN,
	LEFT_BRACKET_TOKEN,
	RIGHT_BRACKET_TOKEN,
	DOUBLE_QUOTATION_TOKEN,
	SINGLE_QUOTATION_TOKEN,
	//operators
	INCR_OPERATOR_TOKEN,
	DECR_OPERATOR_TOKEN,
	ADD_OPERATOR_TOKEN,
	SUB_OPERATOR_TOKEN,
	MUL_OPERATOR_TOKEN,
	DIV_OPERATOR_TOKEN,
	POW_OPERATOR_TOKEN,
	ASSIGN_OPERATOR_TOKEN,
	//COND oper
	C_OR_OPERATOR_TOKEN,
	C_AND_OPERATOR_TOKEN,
	NOT_OPERATOR_TOKEN,
	//compare
	EQUAL_TOKEN,
	NOT_EQUAL_TOKEN,
	HIGHER_TOKEN,
	LOWER_TOKEN,
	HE_TOKEN,
	LE_TOKEN,
	//BYTE oper
	B_OR_OPERATOR_TOKEN,
	B_AND_OPERATOR_TOKEN,
	//NOT_OPERATOR_TOKEN,
	//type
	STRING_TOKEN,
	DOUBLE_TOKEN,
	INT_TOKEN,
	CHAR_TOKEN,
	BOOL_TOKEN,
	STRUCT_TOKEN,
	//file symble
	END_OF_LINE_TOKEN,
	END_OF_FILE_TOKEN,
	//comma
	COMMA_TOKEN,
	DOT_TOKEN,
	SEMI_TOKEN,
	//prop
	CONST_TOKEN,
	STATIC_TOKEN,
	//comment
	LEFT_COMMENT_TOKEN,
	RIGHT_COMMENT_TOKEN,
	COMMENT_TOKEN,
	//circulate
	CONTINUE_TOKEN,
	BREAK_TOKEN,
	//PRE_COMPILE
	INCLUDE_TOKEN,
	INCLUDE_ONCE_TOKEN,
	//UTILS
	PAUSE_TOKEN,
	CLEAR_TOKEN,
	PRINT_OUT_TOKEN,
	SCAN_IN_TOKEN,
	SCAN_IN_CHAR_TOKEN,
	SCAN_IN_LINE_TOKEN,
	EXIT_TOKEN,
	//class
	CLASS_TOKEN,
	CLASS_NUMBER_TOKEN,
	//STRUCT_TOKEN,
	TYPEDEF_TOKEN
}token_type_t;

//for true value
typedef union {
	double	dd_v;
	int		int_v;
}token_value_t;

//for levels of token syms
enum class token_sym_level_t{
	_Bad_level,
	_1,
	_2,
	_3,
	_4,
	_5,
	_6,
	_7,
	_8,
	_9,
	_10,
	_11,
	_12,
	_13,
	_14,
	_15,
	_16
};

//for token
struct token_value_use_t{
	token_value_use_t()
		:kind(BAD_TOKEN){}
	token_type_t	kind;
	token_value_t	value;
	//string str;
	void* pval_ref;
};

struct token_t :public token_value_use_t {
	string str;
	
	token_value_use_t get_use_t() {
		token_value_use_t ret;
		ret.kind = kind;
		ret.value = value;
		ret.pval_ref = pval_ref;
		return ret;
	}
	token_t(void *pval) {
		pval_ref = pval;
		kind = REF_TOKEN;
	}
	token_t()
		:token_value_use_t(){}
	token_t(token_t &t){
		kind = t.kind;
		str = t.str;
		value = t.value;
	}
	token_t(token_value_use_t &t) {
		kind = t.kind;
		value = t.value;
	}
	token_t(token_value_t &t) {
		//**union warn!!
		value = t;
	}
	token_t(string &&t) {
		//kind = STRING_TOKEN;
		//str = Forward<string>(t);
		str = t;
	}
	token_t(int t) {
		kind = INT_NUMBER_TOKEN;
		value.int_v = t;
	}
};
//struct a_line_of_tokens {
//	deq<token_t> tokens;
//};
typedef deq<token_t> token_group_t;
/*
typedef struct  {
	token_type_t type;
	union {
		normal_statement _normal;
		if_statment _if;
		while_statement _while;
		//token_group_t *func_goes;
	};
}token_group_elem_t;
typedef deq<token_group_elem_t> token_group_t;	//big env statement
struct cond_goes {
	a_line_of_tokens cond;
	token_group_t codes;
};
struct normal_statement{
	deq<a_line_of_tokens> tokens;
};
struct if_statment{
	deq<cond_goes> if_goes;	//if and elif
	token_group_t else_goes;
};
struct while_statement{
	cond_goes cir_goes;
};*/

inline token_sym_level_t token_sym_level(token_type_t t) {
	switch (t) {
	case POW_OPERATOR_TOKEN:
		return token_sym_level_t::_3;
	case MUL_OPERATOR_TOKEN:
	case DIV_OPERATOR_TOKEN:
		return token_sym_level_t::_4;
	case ADD_OPERATOR_TOKEN:
	case SUB_OPERATOR_TOKEN:
	case INCR_OPERATOR_TOKEN:
	case DECR_OPERATOR_TOKEN:
		return token_sym_level_t::_5;
	case HIGHER_TOKEN:
	case LOWER_TOKEN:
	case HE_TOKEN:
	case LE_TOKEN:
		return token_sym_level_t::_6;
	case EQUAL_TOKEN:
	case NOT_EQUAL_TOKEN:
		return token_sym_level_t::_7;
	case C_AND_OPERATOR_TOKEN:
		return token_sym_level_t::_11;
	case C_OR_OPERATOR_TOKEN:
		return token_sym_level_t::_12;
	//case ASSIGN_OPERATOR_TOKEN:
	//	return token_sym_level_t::_14;
	default:
		return token_sym_level_t::_Bad_level;
	}
}
inline int token_compare(token_type_t left, token_type_t right) {
	return (int)left - (int)right;
}
inline int token_sym_level_compare(token_type_t left, token_type_t right) {
	return (int)token_sym_level(left) - (int)token_sym_level(right);
}
inline bool is_single_token_sym(token_type_t t) {
	switch (t)
	{
	case INCR_OPERATOR_TOKEN:
	case DECR_OPERATOR_TOKEN:
	case NOT_OPERATOR_TOKEN:
		return true;
	}
	return false;
}
inline bool is_int_token(token_type_t t) {
	return t == INT_NUMBER_TOKEN || t==INT_TOKEN;
}
inline bool is_double_token(token_type_t t) {
	return t == DD_NUMBER_TOKEN || t==DOUBLE_TOKEN;
}
inline bool is_number_token_kind(token_type_t t) {
	switch (t)
	{
	case INT_NUMBER_TOKEN:
	case DD_NUMBER_TOKEN:
	case BOOL_NUMBER_TOKEN:
	case CHAR_NUMBER_TOKEN:
		return true;
	default:
		return false;
	}
}
inline bool is_integer_number_token_kind(token_type_t t) {
	switch (t)
	{
	case INT_NUMBER_TOKEN:
	//case DD_NUMBER_TOKEN:
	case BOOL_NUMBER_TOKEN:
	case CHAR_NUMBER_TOKEN:
		return true;
	default:
		return false;
	}
}

inline bool is_integer_type_token_kind(token_type_t t) {
	switch (t)
	{
	case INT_TOKEN:
	case BOOL_TOKEN:
	case CHAR_TOKEN:
		return true;
	default:
		return false;
	}
}
inline bool is_number_type_token_kind(token_type_t t) {
	switch (t)
	{
	case INT_TOKEN:
	case DOUBLE_TOKEN:
	case BOOL_TOKEN:
	case CHAR_TOKEN:
		return true;
	default:
		return false;
	}
}
inline token_sym_level_t dec_token_sym_level(token_sym_level_t t) {
	int i = int(t) - 1;
	return (token_sym_level_t)i;
}
inline bool is_type_token(token_type_t t) {
	switch (t)
	{
	case INT_TOKEN:
	case DOUBLE_TOKEN:
	case BOOL_TOKEN:
	case CHAR_TOKEN:
	case STRING_TOKEN:
	case VOID_TOKEN:
		return true;
	default:
		return false;
	}
}
inline bool is_value_type(token_type_t t) {//not include VOID_TOKEN
	switch (t)
	{
	case INT_TOKEN:
	case DOUBLE_TOKEN:
	case BOOL_TOKEN:
	case CHAR_TOKEN:
	case STRING_TOKEN:
		return true;
	default:
		return false;
	}
}
inline bool is_single_opt(token_type_t t) {
	switch (t)
	{
	case NOT_OPERATOR_TOKEN:
	case INCR_OPERATOR_TOKEN:
	case DECR_OPERATOR_TOKEN:
		return true;
	default:
		return false;
	}
}
inline token_type_t number_to_type(token_type_t t) {//convert NUMBERTOKEN to type token
	switch (t)
	{
	case INT_NUMBER_TOKEN:
		return INT_TOKEN;
	case DD_NUMBER_TOKEN:
		return DOUBLE_TOKEN;
	case BOOL_NUMBER_TOKEN:
		return BOOL_TOKEN;
	case STRING_NUMBER_TOKEN:
		return STRING_TOKEN;
	case CHAR_NUMBER_TOKEN:
		return CHAR_TOKEN;
	default:
		return t;
		//break;
	}
}
inline token_type_t type_to_number(token_type_t t) {
	switch (t)
	{
	case INT_TOKEN:
		return INT_NUMBER_TOKEN;
	case DOUBLE_TOKEN:
		return DD_NUMBER_TOKEN;
	case CHAR_TOKEN:
		return CHAR_NUMBER_TOKEN;
	case BOOL_TOKEN:
		return BOOL_NUMBER_TOKEN;
	case STRING_TOKEN:
		return STRING_NUMBER_TOKEN;
	default:
		return t;
	}
}
inline bool is_compare_op(token_type_t t) {
	switch (t)
	{
	case EQUAL_TOKEN:
	case C_OR_OPERATOR_TOKEN:
	case C_AND_OPERATOR_TOKEN:
	case NOT_EQUAL_TOKEN:
	case HIGHER_TOKEN:
	case LOWER_TOKEN:
	case HE_TOKEN:
	case LE_TOKEN:
		return true;
	default:
		break;
	}return false;
}

inline bool is_string_token(token_type_t t) {
	return t == STRING_TOKEN || t == STRING_NUMBER_TOKEN;
}
inline void add_eof_token(token_group_t &p) {
	token_t tmp;
	tmp.kind = END_OF_FILE_TOKEN;
	p.emplace_back(tmp);
}
inline string get_type_name_str(token_type_t t) {
	string g;
	switch (t)
	{
	case DOUBLE_TOKEN:
	case DD_NUMBER_TOKEN:
		g = "double";
		break;
	case INT_TOKEN:
	case INT_NUMBER_TOKEN:
		g = "int";
		break;
	case BOOL_TOKEN:
	case BOOL_NUMBER_TOKEN:
		g = "bool";
		break;
	case CHAR_TOKEN:
	case CHAR_NUMBER_TOKEN:
		g = "char";
		break;
	default:
		break;
	}
	return g;
}
inline void add_semi_token(token_group_t &p) {
	token_t tkSEMI;
	tkSEMI.kind = SEMI_TOKEN;
	tkSEMI.str = ";";
	p.emplace_back(tkSEMI);
}
inline token_t make_token(token_type_t t) {
	token_t st;
	st.kind = t;
	return st;
}
inline bool is_require(token_type_t t) {
	switch (t)
	{
	case INCLUDE_TOKEN:
	case INCLUDE_ONCE_TOKEN:
		return true;
	default:
		return false;
	}
}
#endif
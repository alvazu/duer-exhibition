/*queue adapter by Alvazu*/
#pragma once
#include "deq.h"
template <typename _Ty, typename _Container = deq<_Ty>> class Queue {

public:
	using _Myt = Queue;
	using container_type = typename _Container;
	using value_type = typename _Container::value_type;
	using size_type = typename _Container::size_type;
	using reference = typename _Container::reference;
	using const_reference = typename _Container::const_reference;
	static_assert(_STD is_same<_Ty, value_type>::value, "container adaptors require consistent types");
	Queue() {}
	Queue(const_reference v) :c(v) {}
	Queue(value_type &&v) :c(Move(v)) {}
	Queue(const _Container &p) :c(p) {}
	Queue(_Container &&p) :c(Move(p)) {}
	Queue &operator=(Queue &&q) {
		c = Move(q.c);
		return *this;
	}
	void push(value_type&& _Val)
	{	// insert element at beginning
		c.push_back(Move(_Val));
	}

	template<class... _Valty>
	void emplace(_Valty&&... _Val)
	{	// insert element at beginning
		c.emplace_back(Forward<_Valty>(_Val)...);
	}

	bool empty() const
	{	// test if queue is empty
		return (c.empty());
	}

	size_type size() const
	{	// return length of queue
		return (c.size());
	}

	reference front()
	{	// return first element of mutable queue
		return (c.front());
	}

	const_reference front() const
	{	// return first element of nonmutable queue
		if (c.size() == 0)throw _STD runtime_error("queue blank");
		return (c.front());
	}

	reference back()
	{	// return last element of mutable queue
		return (c.front());
	}

	const_reference back() const
	{	// return last element of nonmutable queue
		return (c.back());
	}

	void push(const value_type& _Val)
	{	// insert element at beginning
		c.push_back(_Val);
	}

	void pop()
	{	// erase element at end
		c.pop_front();
	}

	_Container& _Get_container()
	{	// get reference to container
		return (c);
	}

	void swap(_Myt& _Right)
		_NOEXCEPT_OP(_STD _Is_nothrow_swappable<_Container>::value)
	{	// exchange contents with _Right
		_STD _Swap_adl(c, _Right.c);
	}


protected:
	container_type c;
};

// queue TEMPLATE FUNCTIONS
template<class _Ty,
	class _Container,
	class = _STD enable_if_t<_STD _Is_swappable<_Container>::value>> inline
	void swap(Queue<_Ty, _Container>& _Left,
		Queue<_Ty, _Container>& _Right)
	_NOEXCEPT_OP(_NOEXCEPT_OP(_Left.swap(_Right)))
{	// swap _Left and _Right queues
	_Left.swap(_Right);
}

template<class _Ty,
	class _Container> inline
	bool operator==(const Queue<_Ty, _Container>& _Left,
		const Queue<_Ty, _Container>& _Right)
{	// test for queue equality
	return (_Left._Get_container() == _Right._Get_container());
}

template<class _Ty,
	class _Container> inline
	bool operator!=(const Queue<_Ty, _Container>& _Left,
		const Queue<_Ty, _Container>& _Right)
{	// test for queue inequality
	return (!(_Left == _Right));
}

template<class _Ty,
	class _Container> inline
	bool operator<(const Queue<_Ty, _Container>& _Left,
		const Queue<_Ty, _Container>& _Right)
{	// test if _Left < _Right for queues
	return (_Left._Get_container() < _Right._Get_container());
}

template<class _Ty,
	class _Container> inline
	bool operator>(const Queue<_Ty, _Container>& _Left,
		const Queue<_Ty, _Container>& _Right)
{	// test if _Left > _Right for queues
	return (_Right < _Left);
}

template<class _Ty,
	class _Container> inline
	bool operator<=(const Queue<_Ty, _Container>& _Left,
		const Queue<_Ty, _Container>& _Right)
{	// test if _Left <= _Right for queues
	return (!(_Right < _Left));
}

template<class _Ty,
	class _Container> inline
	bool operator>=(const Queue<_Ty, _Container>& _Left,
		const Queue<_Ty, _Container>& _Right)
{	// test if _Left >= _Right for queues
	return (!(_Left < _Right));
}
#pragma once

//for Move & Forward partly by Alvazu
template<class _Ty,
	_Ty _Val>
	struct integral_const
{	// convenient template for integral constant types
	static constexpr _Ty value = _Val;

	typedef _Ty value_type;
	typedef integral_const<_Ty, _Val> type;

	constexpr operator value_type() const _NOEXCEPT
	{	// return stored value
		return (value);
	}

	constexpr value_type operator()() const _NOEXCEPT
	{	// return stored value
		return (value);
	}
};
typedef integral_const<bool, true> true_type;
typedef integral_const<bool, false> false_type;


template<class _Ty>
struct is_arr
	: ::false_type
{	// determine whether _Ty is an array
};

template<class _Ty, size_t _Nx>
struct is_arr<_Ty[_Nx]>
	: ::true_type
{	// determine whether _Ty is an array
};

template<class _Ty>
struct is_arr<_Ty[]>
	: ::true_type
{	// determine whether _Ty is an array
};
template <typename _Ty> class remove_ref {
public:
	typedef _Ty type;
};
template <typename _Ty> class remove_ref<_Ty &> {
public:
	typedef _Ty type;
};
template <typename _Ty> class remove_ref<_Ty &&> {
public:
	typedef _Ty type;
};
template<class _Ty>
struct is_lvalue_ref
	: ::false_type
{
};

template<class _Ty>
struct is_lvalue_ref<_Ty&>
	: ::true_type
{
};
template <typename _Ty>
inline typename remove_ref<_Ty>::type && Move(_Ty && __t) {
	return static_cast<typename remove_ref<_Ty>::type &&>(__t);
}
template<typename _Tp>	//perfect relay
constexpr inline _Tp&& Forward(typename remove_ref<_Tp>::type& __t)
{
	return static_cast<_Tp&&>(__t);
}

template<typename _Tp>	//perfect relay
constexpr inline _Tp&& Forward(typename remove_ref<_Tp>::type&& __t)
{
	static_assert(is_lvalue_ref<_Tp>::value, "bad forward: rvalue");
	return static_cast<_Tp&&>(__t);
}
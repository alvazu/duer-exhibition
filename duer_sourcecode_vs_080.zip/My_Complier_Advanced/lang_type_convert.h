#pragma once
#include "lang_run.h"
#include "ptr_se.h"
#include "pair.h"
#include <string>
#include <sstream>
//#include "syntactic_analyzer.h"

using _STD string;
template <class _Ty>
string _convert_to_string(_Ty t) {
	_STD stringstream ss;
	ss << t;
	return ss.str();
}
double _str_convert_to_dd(string &t) {
	double g;
	_STD stringstream ss(t);
	ss >> g;
	return g;
}
Pair<base_variable_t*,int> ref_get_iden(base_variable_t* pt) {
	int isconst = 0;
	while (pt->type == REF_TOKEN)
	{
		if (pt->isconst) isconst = 1;
		pt = pt->value.ppval.ptr;
	}
	if (pt->isconst) isconst = 1;
	return Pair<base_variable_t*, int>(pt, isconst);
}
sh_ptr<token_t> ref_get_iden(sh_ptr<token_t> pt) {
	bool isref = pt->kind == REF_TOKEN;
	if (isref) {
		base_variable_t *pbase = reinterpret_cast<base_variable_t *>(pt->pval_ref);
		while (pbase->type == REF_TOKEN)
			pbase = pbase->value.ppval.ptr;
	//	pbase
		sh_ptr<token_t> rett;
		if (!is_string_token(pbase->type))
			rett = allocate_sh<token_t>(pbase->value.nval);
		else 
			rett = allocate_sh<token_t>(Move(pbase->value.sval));	//**Move may cause problems: Warning
		rett->kind = pbase->type;
		return rett;
	}
	else return pt;
}
void convert_to_string(base_variable_t & b) {
	switch (b.type)
	{
	case token_type_t::CHAR_TOKEN:
	case token_type_t::INT_TOKEN:
	case token_type_t::BOOL_TOKEN:
		b.value.sval = _convert_to_string(b.value.nval.int_v);
		break;
	case token_type_t::DOUBLE_TOKEN:
		b.value.sval = _convert_to_string(b.value.nval.dd_v);
		break;
	default:
		break;
	}
	b.type = token_type_t::STRING_TOKEN;
}
void convert_to_string(token_t * b) {
	if (is_string_token(b->kind)) return;
	switch (b->kind)
	{
	case token_type_t::CHAR_TOKEN:
	case token_type_t::CHAR_NUMBER_TOKEN:
		b->str = _convert_to_string((char)(b->value.int_v));
		break;
	case token_type_t::INT_TOKEN:
	case token_type_t::INT_NUMBER_TOKEN:
	case token_type_t::BOOL_TOKEN:
	case token_type_t::BOOL_NUMBER_TOKEN:
		b->str = _convert_to_string(b->value.int_v);
		break;
	case token_type_t::DOUBLE_TOKEN:
	case token_type_t::DD_NUMBER_TOKEN:
		b->str = _convert_to_string(b->value.dd_v);
		break;
	default:
		break;
	}
	b->kind = token_type_t::STRING_TOKEN;
}
void _convert(token_type_t higher,
	base_variable_t &lower)
{
	switch (higher)
	{
	case token_type_t::CHAR_TOKEN:
	case token_type_t::INT_TOKEN:
		break;
	case token_type_t::DOUBLE_TOKEN:
		lower.value.nval.dd_v = (double)lower.value.nval.int_v;
		break;
	default:
		break;
	}
	lower.type = higher;
}
void set_value(base_variable_t *par, sh_ptr<token_t> ptoken) {
	switch (par->type)
	{
	case INT_TOKEN:
	case BOOL_TOKEN:
	case CHAR_TOKEN:
		if(is_double_token(ptoken->kind))par->value.nval.int_v = int(ptoken->value.dd_v);
		else par->value.nval.int_v = ptoken->value.int_v;
		break;
	case DOUBLE_TOKEN:
		if (is_double_token(ptoken->kind)) par->value.nval.dd_v = ptoken->value.dd_v;
		else par->value.nval.dd_v = ptoken->value.int_v;
		break;
	case STRING_TOKEN:
		if (is_double_token(ptoken->kind)) par->value.sval = ptoken->value.dd_v;
		else if(is_int_token(ptoken->kind)) par->value.sval = ptoken->value.int_v;
		else par->value.sval = ptoken->str;
		break;
	default:
		throw _STD runtime_error("type of assign wrong");
		break;
	}
}
void convert_to_str_for_token(token_t *b) {
	switch (b->kind)
	{
	case INT_NUMBER_TOKEN:
		b->str = _convert_to_string(b->value.int_v);
		break;
	case BOOL_NUMBER_TOKEN:
		b->str = _convert_to_string((bool)(b->value.int_v));
		break;
	case CHAR_NUMBER_TOKEN:
		b->str = _convert_to_string((char)(b->value.int_v));
		break;
	case DD_NUMBER_TOKEN:
		b->str = _convert_to_string(b->value.dd_v);
		break;
	case STRING_NUMBER_TOKEN:
	default:
		break;
	}
	b->kind = STRING_NUMBER_TOKEN;
}
void vars_type_convert_for_function_calling(token_t *b, variable_type_t t, bool hard_convert = false) {
	token_t *ob = b;
	if (b->kind != REF_TOKEN && t == REF_TOKEN)
		throw _STD runtime_error("return REF instead of a value");
	if (b->kind == REF_TOKEN) {
		if(t == REF_TOKEN)
			return;
		else {
			auto m = ref_get_iden((base_variable_t *)(b->pval_ref));
			if (is_string_token(m.first->type))
				b->str = m.first->value.sval;
			else b->value = m.first->value.nval;
			b->kind =type_to_number( m.first->type);
		}
	}
	if (!hard_convert)
		if (b->kind == type_to_number(t)) return;
	switch (b->kind)
	{
	case INT_NUMBER_TOKEN:
	case BOOL_NUMBER_TOKEN:
	case CHAR_NUMBER_TOKEN:
		switch (t)
		{
		case INT_TOKEN:
			break;
		case BOOL_TOKEN:
			b->value.int_v = (bool)(b->value.int_v);
			break;
		case CHAR_TOKEN:
			b->value.int_v = (char)(b->value.int_v);
			break;
		case DOUBLE_TOKEN:
			b->value.dd_v = (double)(b->value.int_v);
			break;
		case STRING_TOKEN:
			convert_to_str_for_token(b);
			break;
		default:
			break;
		}
		break;
	case DD_NUMBER_TOKEN:
DD_TK:
		switch (t)
		{
		case INT_TOKEN:
			b->value.int_v = (int)(b->value.dd_v);
			break;
		case BOOL_TOKEN:
			b->value.int_v = (bool)(b->value.dd_v);
			break;
		case CHAR_TOKEN:
			b->value.int_v = (char)(b->value.dd_v);
			break;
		case DOUBLE_TOKEN:
			break;
		case STRING_TOKEN:
			convert_to_str_for_token(b);
			break;
		default:
			break;
		}
		break;
	case STRING_TOKEN:
	case STRING_NUMBER_TOKEN:
		if (t == CHAR_TOKEN) {
			if (b->str.size() > 0)
				b->value.int_v = (char)(b->str[0]);
			else
			{
				b->kind = CHAR_NUMBER_TOKEN;
				b->value.int_v = 0;
				return;
			}
		}
		else if (t == STRING_TOKEN)
			return;
		else {
			b->value.dd_v = _str_convert_to_dd(b->str);
			goto DD_TK;
		}
		break;
	default:
		break;
	}
	b->kind = type_to_number(t);
}
Pair<base_variable_t,base_variable_t> vars_put_together(base_variable_t _left,
	base_variable_t _right)
{	//compare and convert a lower type to a higher type, to the same level
	if (_left.type == _right.type) return Pair<base_variable_t, base_variable_t>(_left, _right);
	if (_left.type == token_type_t::STRING_TOKEN
		|| _right.type == token_type_t::STRING_TOKEN) 
	{
		if (_left.type == token_type_t::STRING_TOKEN)
			convert_to_string(_right);
		else
			convert_to_string(_left);
		return Pair<base_variable_t, base_variable_t>(_left,_right);
	}
	int token_comp = token_compare(_left.type, _right.type);
	if (token_comp < 0)
		_convert(_right.type, _left);
	else if(token_comp > 0)
		_convert(_left.type, _right);
	return Pair<base_variable_t, base_variable_t>(_left, _right);
}

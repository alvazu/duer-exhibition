#ifndef X
#pragma once
#include <string>
#include <iostream>
#include "lexical_analyzer.h"
#include "lang_runner.h"
#include "deq.h"
#include "queue.h"
#define SYNTATIC_ANALYZER_EXCPTION_BEGINNING "\n** SYNTATIC ANALYZER EXCEPTION\n\t"
base_variable_t && get_struct(token_group_t &grp, syntatic_analyzer *sa);
enum crby_t:int{
	CRBY_FOR,
	CRBY_NORMAL,
	CRBY_FUNC
};
void get_a_tk_line_and_delete(token_group_t &to,
	token_group_t &from) {
	while (from.front().kind != SEMI_TOKEN) {
		to.emplace_back(from.front());
		from.pop_front();
	}
	to.emplace_back(from.front());
	from.pop_front();
}
int get_a_tk_line(token_group_t &code_body,
	token_group_t::iterator from,
	token_group_t::iterator end)
{
	int all = 0;
	while (from->kind != SEMI_TOKEN && from != end) {
		code_body.emplace_back(*from);
		from++;
		all++;
	}
	code_body.emplace_back(*from);
	return ++all;
}

void get_brace(token_group_t &code_body,
	token_group_t &from,
	bool isbrace = true,
	int counter_start = 0,
	bool keepit = false) 
{
	int counter = counter_start;
	//token_group_t code_body;
	do {
		if (from.front().kind ==
			(isbrace ? LEFT_BRACE_TOKEN : LEFT_PAREN_TOKEN))
		{
			if (counter != 0 || keepit)
				code_body.emplace_back(from.front());
			from.pop_front();
			counter++;
			continue;
		}
		else if (from.front().kind ==
			(isbrace ? RIGHT_BRACE_TOKEN : RIGHT_PAREN_TOKEN))
		{
			counter--;
			if (counter != 0 || keepit)
				code_body.emplace_back(from.front());
			else break;
			from.pop_front();
			continue;
		}
		if (counter == 0) break;
		code_body.emplace_back(from.front());
		from.pop_front();
	} while (true);
}
size_t get_paren(token_group_t &code_body,
	token_group_t::iterator from,
	token_group_t::iterator end,
	bool isbrace = false,
	int counter_start = 0,
	bool keepit = false)
{
	int counter = counter_start;
	size_t all = 0;
	//token_group_t code_body;
	do {
		if (from == end) throw _STD runtime_error("FOR too long");
		if (from[all].kind == (isbrace ? LEFT_BRACE_TOKEN : LEFT_PAREN_TOKEN))
		{
			if (counter != 0 || !isbrace || keepit)
				code_body.emplace_back(from[all]);
			all++;
			counter++;
			continue;
		}
		else if (from[all].kind ==
			(isbrace ? RIGHT_BRACE_TOKEN : RIGHT_PAREN_TOKEN))
		{
			counter--;
			if (counter != 0 || !isbrace || keepit)
				code_body.emplace_back(from[all]);
			else break;
			all++;
			continue;
		}
		if (counter == 0) break;
		code_body.emplace_back(from[all]);
		all++;
	} while (true);
	return all;
}
class lang_runner;
class syntatic_analyzer;
struct sa_data {
	using ptoken_t = sh_ptr<token_t>;
	using queue_of_token_t = Queue<token_t>;
	sa_data()
		:is(nullptr),
		is_look_ahead_exists(0),
		inpar(0),
		created_by_who(CRBY_NORMAL),
		have_return(0)
	{
	}
	sa_data(sa_data &&sa) {
		tkqueue._Get_container() = Move(sa.tkqueue._Get_container());
		is = sa.is;
		look_ahead = sa.look_ahead;
		is_look_ahead_exists = sa.is_look_ahead_exists;
		inpar = sa.inpar;
		created_by_who = sa.created_by_who;
		have_return = sa.have_return;
	}
	void operator=(sa_data &&sa) {
		tkqueue._Get_container() = Move(sa.tkqueue._Get_container());
		is = sa.is;
		look_ahead = Move(sa.look_ahead);
		is_look_ahead_exists = sa.is_look_ahead_exists;
		created_by_who = sa.created_by_who;
		have_return = sa.have_return;
	}
	void init() {
		inpar = 0;
		have_return = 0;
		//created_by_who = CRBY_NORMAL;
		is = nullptr;
		is_look_ahead_exists = 0;
		tkqueue._Get_container().clear();
	}
	int inpar;
	//bool depar;
	int have_return;
	crby_t created_by_who;
	queue_of_token_t tkqueue;
	istream *is;
	ptoken_t look_ahead;
	int is_look_ahead_exists;

};
class syntatic_analyzer {
	
public:
	
	using ptoken_t = sh_ptr<token_t>; 
	friend inline typename syntatic_analyzer::ptoken_t Go_syn(token_group_t &m,
		syntatic_analyzer *psyn,
		int *for_going);
	using queue_of_token_t = Queue<token_t>;
	explicit syntatic_analyzer()
	{	//construct by nothing
	}
	//explicit syntatic_analyzer(istream &is) :
	//	la(is), is(&is), is_look_ahead_exists(0) 
	//{	//construct by istream
	//}
	void _Unget_a_token(ptoken_t ptoken) {
		data.look_ahead = ptoken;
		data.is_look_ahead_exists = 1;
	}
	void save_everything(crby_t by_who) {
		
		saver.emplace_back(Move(data));
		data.init();
		data.created_by_who = by_who;
		//saver.emplace_back(Move(data));
	}
	ptoken_t go(token_group_t &&m) {
		data.tkqueue._Get_container() = Forward<token_group_t>(m);
		auto ret = parse_line();
		return ret;
	}
	void _unsave_one() {
		if (saver.size() > 0)
			data = saver.pop_back();
		else
			throw _STD runtime_error("nothing to unsave");
	}
	void unsave_everything(crby_t to_who){
		switch (to_who)
		{
		case CRBY_FUNC:
			while(data.created_by_who != CRBY_FUNC)
				_unsave_one();
			break;
		case CRBY_FOR:
			while (data.created_by_who != CRBY_FOR)
				_unsave_one();
			break;
		default:
			break;
		}
		_unsave_one();
	}
	lang_runner *prun_env;
private:

	void noconst_or_stat(bool c,bool s) {
		if (c || s) throw _STD runtime_error("bad const or static");
	}
	bool iszero(ptoken_t &t) {
		if (!t.available())return true;
		if (is_integer_number_token_kind(t->kind)
			|| is_integer_type_token_kind(t->kind))
			return t->value.int_v == 0;
		if (t->kind == DD_NUMBER_TOKEN
			|| t->kind == DOUBLE_TOKEN)
			return t->value.dd_v == 0.0;
		if (t->kind == STRING_NUMBER_TOKEN
			|| t->kind == STRING_TOKEN)
			return t->str.empty();
		return false;
	}
	ptoken_t parse_line()
	{	//deal a line
		data.is_look_ahead_exists = 0;
		ptoken_t ret = _Process();
		return ret;
	}
	ptoken_t _Get_a_token()
	{
		bool isglobal = false;
		int isfront = 0;
		token_type_t single_op = BAD_TOKEN;
		bool isnew = false;
		bool isstatic = false;
		bool isconst = false;
		if (data.is_look_ahead_exists) {
			data.is_look_ahead_exists = 0;
			if (data.look_ahead->kind == COMMA_TOKEN || data.look_ahead->kind == SEMI_TOKEN) {
				data.is_look_ahead_exists = 1; 
				return nullptr; 
			}
			return data.look_ahead;
		}
		else {
ELSE:
			if (data.tkqueue.size() == 0) return nullptr;
			ptoken_t ret = allocate_sh<token_t>(data.tkqueue.front());
			data.tkqueue.pop();
			if (ret->kind == END_OF_FILE_TOKEN
				|| ret->kind == COMMA_TOKEN
				|| ret->kind == SEMI_TOKEN
				|| data.tkqueue.size() == 0) {	//COMMA for function calc
				if (ret->kind == COMMA_TOKEN) data.inpar = 1;
				if (ret->kind == COMMA_TOKEN || ret->kind == SEMI_TOKEN) { _Unget_a_token(ret); }
				return nullptr;
			}
			else if (ret->kind == RIGHT_PAREN_TOKEN) {
				_Unget_a_token(ret);
				return nullptr;
			}
			else if (ret->kind == NEW_TOKEN) {
				//data.tkqueue.pop();	//throw new
				if (!is_type_token(data.tkqueue.back().kind))
					_Syntax_error("NEW WHAT ?");
				token_type_t NEW_T = data.tkqueue.back().kind;
				data.tkqueue.pop();	//throw type
				ptoken_t res;
				if (data.tkqueue.back().kind == LEFT_PAREN_TOKEN)	//get initial
				{
					token_group_t init;
					get_brace(init, data.tkqueue._Get_container(), false, 0, false);

					init.emplace_back(data.tkqueue.back());
					data.tkqueue.pop();
					if (init.size() == 1)
						goto PELSE;
					save_everything(CRBY_NORMAL);
					data.tkqueue._Get_container() = Move(init);
					//token_group_t shell;
					//get_brace(shell, data.tkqueue._Get_container(), false, 0, false);
					//data.tkqueue._Get_container() = Move(shell);
					res = _Process();
					unsave_everything(CRBY_NORMAL);
				}
				else {
				PELSE:
					res = allocate_sh<token_t>();
					res->kind = INT_NUMBER_TOKEN;
					res->value.int_v = 0;
					vars_type_convert_for_function_calling(res.get(), NEW_T, false);
				}
				base_variable_t *tmp = prun_env->add_value_to_heap(NEW_T, res, isconst, isstatic);
				//tmp->value.pclval=
				return allocate_sh<token_t>((void *)tmp);
				//	return nullptr;
				
			}
			else if (ret->kind == RETURN_TOKEN) {
				data.have_return = 1;
				auto MM = _Process();
				return MM;
			}
			else if (ret->kind == CONST_TOKEN) {
				isconst = true;
				goto ELSE;
			}
			else if (ret->kind == STATIC_TOKEN) {
				isstatic = true;
				goto ELSE;
			}
			else if (ret->kind == GLOBAL_TOKEN) {
				
				if (data.tkqueue.back().kind != NAME_TOKEN)
					_Syntax_error("bad global token");
				isglobal = true;
				goto ELSE;
			}
			else if (ret->kind == STRUCT_TOKEN) {
				try {
					string clsname;
					if (data.tkqueue.back().kind != NAME_TOKEN) throw -1;
					clsname = Move(data.tkqueue.back().str);
					data.tkqueue.pop();
					//get name
					if (data.tkqueue.back().kind != LEFT_BRACE_TOKEN) {	//create instance
						myclass_define_t *mycls = prun_env->get_env()->find_class(clsname);
						if (mycls == nullptr) throw 2;
						base_variable_t tmp;
						tmp.type = CLASS_NUMBER_TOKEN;
						tmp.class_type = Move(clsname);
						tmp.value.pclval = allocate_sh<myclass_instance_t>(mycls);
						if (data.tkqueue.back().kind != NAME_TOKEN) throw 2;
						string name(Move(data.tkqueue.back().str));
						if (data.tkqueue.back().kind == LEFT_PAREN_TOKEN) {	//initial
							token_group_t struct_deq;
							get_brace(struct_deq, data.tkqueue._Get_container(), false, 0, false);
							//save_everything(CRBY_NORMAL);
							tmp = get_struct(struct_deq,this);
							//unsave_everything(CRBY_NORMAL);
						}
						prun_env->get_env()->add_value(name,tmp,isconst,isstatic);

					}
					else {		//new class
						data.tkqueue.pop();
						myclass_define_t::inner_var_t tmp;
						//get body
						deq<string> seq;
						while (data.tkqueue.back().kind != RIGHT_BRACE_TOKEN) {
							myclass_define_t::myclass_type_info tinfo;
							
							//get const
							if (data.tkqueue.back().kind == CONST_TOKEN) {
								_STD get<0>(tinfo) = 1;
								data.tkqueue.pop();
							}
							else
								_STD get<0>(tinfo) = 0;
							//if base value
							if (is_value_type(data.tkqueue.back().kind))
								_STD get<1>(tinfo) = data.tkqueue.back().kind;
							else {
								_STD get<1>(tinfo) = CLASS_NUMBER_TOKEN;
								//data.tkqueue.pop();
								if (data.tkqueue.back().kind == NAME_TOKEN)
									_STD get<2>(tinfo) = data.tkqueue.back().str;
								else
									throw (-1);
								if (prun_env->get_env()->find_class(data.tkqueue.back().str) == nullptr)
									throw 2;
							}
							data.tkqueue.pop();
							if (data.tkqueue.back().kind == NAME_TOKEN) {
								tmp[data.tkqueue.back().str] = Move(tinfo);
								seq.emplace_back(data.tkqueue.back().str);
							}
							else
								throw - 1;
						}
						//create new class
						prun_env->get_env()->add_class(clsname, myclass_define_t(clsname, Move(tmp), Move(seq)));
					}
				}
				catch (int i) {
					if(i==-1) _Syntax_error("Bad struct");
					else _Syntax_error("no such a type");
				}
			}
			else if (is_require(ret->kind)) {	//require a file
				noconst_or_stat(isconst, isstatic);
				if (data.tkqueue.back().kind != STRING_NUMBER_TOKEN)
					_Syntax_error("BAD REQUIRE");
				string file_path = data.tkqueue.back().str;
				data.tkqueue.pop();
				save_everything(CRBY_NORMAL);
				if(-2!=prun_env->_import(file_path,(ret->kind == INCLUDE_ONCE_TOKEN)))
				
				//data.tkqueue.pop();
				unsave_everything(CRBY_NORMAL);
				return nullptr;
			}
			//BUILT_IN_FUNCS
			else if (ret->kind == EXIT_TOKEN) {
				ptoken_t s = _Process();
				int qt = 0;
				//string exit = "\n**INT COERSION QUIT PROCESS(";
				
				if (s.available() && is_int_token(s->kind))
					qt = s->value.int_v;
				_STD stringstream ss;
				ss << "\n**INT COERSION QUIT PROCESS(" << qt << ").";
				
				//exit += qt;
				//exit += ").";
				throw _STD runtime_error(ss.str());
			}
			else if (ret->kind== PAUSE_TOKEN) {
				system("pause");
				return nullptr;
			}
			else if (ret->kind == CLEAR_TOKEN) {
				system("cls");
				return nullptr;
			}
			else if (ret->kind == PRINT_OUT_TOKEN) {
				ptoken_t s = _Process();
				if (!s.available() || !is_string_token(s->kind)) 
					_Syntax_error("not printing string");
				else
					_STD cout << (s->str);
				return nullptr;
			}
			else if (ret->kind == SCAN_IN_TOKEN) {
				ptoken_t s(new token_t);
				_STD cin >> s->str;
				s->kind = STRING_NUMBER_TOKEN;
				return s;
			}
			else if (ret->kind == SCAN_IN_CHAR_TOKEN) {
				char i;
				ptoken_t s(new token_t);
				_STD cin >> i;
				s->str = i;
				s->kind = CHAR_NUMBER_TOKEN;
				return s;
			}
			else if (ret->kind == SCAN_IN_LINE_TOKEN) {
				ptoken_t s(new token_t);
				_STD getline(_STD cin, s->str);
				s->kind = STRING_NUMBER_TOKEN;
				return s;
			}
			else if (ret->kind == IF_TOKEN) {
				noconst_or_stat(isconst, isstatic);
				//if IF in FOR, then BREAK cause, the number of jmp out current
				prun_env->add_new_env_if();
				token_group_t cond;
				get_brace(cond, data.tkqueue._Get_container(), false, 0, false);
				add_semi_token(cond);
				data.tkqueue.pop();

				//cond ok
				token_group_t if_body, else_body;
				if (data.tkqueue.back().kind == LEFT_BRACE_TOKEN) {
					get_brace(if_body, data.tkqueue._Get_container());
					data.tkqueue.pop();
				}
				else {
					get_a_tk_line_and_delete(if_body, data.tkqueue._Get_container());
					//data.tkqueue.pop();
				}

				


				if (data.tkqueue.back().kind == ELSE_TOKEN) {
					data.tkqueue.pop();
					if (data.tkqueue.back().kind == LEFT_BRACE_TOKEN) {
						get_brace(else_body, data.tkqueue._Get_container());
						data.tkqueue.pop();
					}
					else
						get_a_tk_line_and_delete(else_body, data.tkqueue._Get_container());
				}
				/*
				{
					_STD for_each(if_body.begin(), if_body.end(), [&](token_t &p) {
						_STD cout << p.str << _STD endl;
					});
				}
				{
					_STD for_each(else_body.begin(), else_body.end(), [&](token_t &p) {
						_STD cout << p.str << _STD endl;
					});
				}*/
				//body ok
				save_everything(CRBY_NORMAL);
				data.tkqueue._Get_container() = Move(cond);
				ptoken_t con = _Process();
				unsave_everything(CRBY_NORMAL);
				token_group_t &next_do = if_body;
				if (iszero(con)) {
					if (else_body.empty())
						return nullptr;
					next_do = else_body;
				}
				//is cond == 1 or 0
				save_everything(CRBY_NORMAL);
				int for_good = 0;
				auto ret = Go_syn(next_do, this, &for_good);
				if (for_good == 1) {//break
					unsave_everything(CRBY_NORMAL);
					data.have_return = 2;
					return nullptr;//allocate_sh<token_t>(make_token(BREAK_TOKEN));
				}
				else if (for_good == 2) {//continue
					unsave_everything(CRBY_NORMAL);
					data.have_return = 3;
					return nullptr;// allocate_sh<token_t>(make_token(CONTINUE_TOKEN));
				}
				else if (for_good == 3 || data.have_return == 1) return ret;
				prun_env->del_env_if();
				unsave_everything(CRBY_NORMAL);
				return nullptr;
			}
			else if (ret->kind == FOR_TOKEN) {	//CIRCLE
				noconst_or_stat(isconst, isstatic);
				if (data.tkqueue.back().kind != LEFT_PAREN_TOKEN)
					throw _STD runtime_error("bad for");
				data.tkqueue.pop();
				prun_env->add_new_env_cir();		//1
				token_group_t first_do;
				while (data.tkqueue.back().kind != SEMI_TOKEN) {
					first_do.emplace_back(data.tkqueue.back());
					data.tkqueue.pop();
				}
				first_do.emplace_back(data.tkqueue.back());
				data.tkqueue.pop();
				save_everything(CRBY_NORMAL);
				Go_syn(first_do, this, nullptr);	//do first thing
				unsave_everything(CRBY_NORMAL);

				//_Process();	
				//prun_env->add_new_env();
			//cond
				token_group_t cond;
				while (data.tkqueue.back().kind != SEMI_TOKEN) {
					cond.emplace_back(data.tkqueue.back());
					data.tkqueue.pop();
				}
				if(cond.empty())
					cond.emplace_back(1);
				cond.emplace_back(data.tkqueue.back());
				data.tkqueue.pop();

			//
				token_group_t end_doing;
				get_brace(end_doing, data.tkqueue._Get_container(), false, 1);
				token_t tkSEMI;
				tkSEMI.kind = SEMI_TOKEN;
				tkSEMI.str = ";";
				end_doing.emplace_back(tkSEMI);
			//
				token_group_t code_body;
				auto deb = data.tkqueue.back().kind;
				data.tkqueue.pop();
				auto deb2 = data.tkqueue.back().kind;
				auto n= data.tkqueue.back().str;
				if (data.tkqueue.back().kind != LEFT_BRACE_TOKEN) {	//get a line
					while (data.tkqueue.back().kind != SEMI_TOKEN) {
						code_body.emplace_back(data.tkqueue.back());
						data.tkqueue.pop();
					}
					code_body.emplace_back(data.tkqueue.back());
					data.tkqueue.pop();
				}
				else {
					get_brace(code_body, data.tkqueue._Get_container());
					data.tkqueue.pop();
				}
			//
				save_everything(CRBY_FOR);
				while (true) {
					data.init();
					int _for_good = false;	//for's position
					data.tkqueue._Get_container() = cond;
					ptoken_t condt = _Process();	//get cond result
					data.init();
					if (iszero(condt)) break;
					ptoken_t rett = Go_syn(code_body, this, &_for_good);
					if (_for_good == 1) break;
					else if (_for_good == 2) continue;
					else if (_for_good == 3 || data.have_return == 1) return rett;
					data.init();
					data.tkqueue._Get_container() = end_doing;
/*
{
_STD for_each(end_doing.begin(), end_doing.end(), [&](token_t &p) {
_STD cout << p.str << _STD endl;
});
}*/
					_Process();
					//Go_syn(end_doing, this, nullptr, nullptr);
					//data.init();
				}
				unsave_everything(CRBY_FOR);
				prun_env->break_out();
			}
			else if (ret->kind == NAME_TOKEN && data.tkqueue.back().kind == ASSIGN_OPERATOR_TOKEN) 
			{ //assign
				noconst_or_stat(isconst, isstatic);
				base_variable_t *for_ref = prun_env->get_env()->find_value(ret->str);

				data.tkqueue.pop();
				auto reti = _Process();
				prun_env->modify_value(ret->str, isglobal, reti);
				return reti;
				//goto ELSE;
				//might cause error: a=b+c=6
			}
			else if (ret->kind == NAME_TOKEN) {	//meet a NAME
				noconst_or_stat(isconst, isstatic);
				syn_connect_value_t tmp;
				tmp.name = ret->str;
				ptoken_t pt_ret = allocate_sh<token_t>(data.tkqueue.back());
				if (pt_ret->kind != LEFT_PAREN_TOKEN) {	// not function
					tmp.is_func = false;
					if (is_single_opt(pt_ret->kind)) {
						data.tkqueue.pop();
						return prun_env->get_value(Move(tmp), isglobal, pt_ret->kind);
					}
					else if (isfront)
						return prun_env->get_value(Move(tmp), isglobal, single_op, true);
					return prun_env->get_value(Move(tmp), isglobal);
				}
				else {	//call a function
					data.tkqueue.pop();	//throw left paren
					tmp.is_func = true;
					//queue_of_token_t token_save(Move(tkqueue));
					size_t counter = 1;
					data.inpar = 1;
					//data.depar = 1;
					while (true) {
						//if (tkqueue.back().kind == LEFT_PAREN_TOKEN) counter++;
						if (data.inpar == 0) break;
						
						//if (!counter) break;
						//string *mt;
						auto m = _Process();
						if (!(m.available())) break;
						if (is_string_token(m->kind))
							m->pval_ref = new string(Move(m->str));
						auto m2=m->get_use_t();
						tmp.value.emplace_back(m2, 0);
						//tkqueue.pop();
						if (data.is_look_ahead_exists == 1
							&& data.look_ahead->kind == COMMA_TOKEN)
							data.is_look_ahead_exists = 0;
						
					}
					data.inpar = 0;
					return prun_env->call_a_function(Move(tmp), isglobal);
				}
			}
			else if (is_single_opt(ret->kind)) {		//single opt
				noconst_or_stat(isconst, isstatic);
NOT_NAME:
				//
					if (data.tkqueue.back().kind == GLOBAL_TOKEN) {
						isglobal = true;
						data.tkqueue.pop();
						goto NOT_NAME;
						//if (data.tkqueue.back().kind != NAME_TOKEN)
						//	_Syntax_error("single opr not for rval");
					}
					else {
						if (ret->kind == NOT_OPERATOR_TOKEN) {
							//data.tkqueue.pop();
							token_group_t exp;
							if (data.tkqueue.back().kind == LEFT_PAREN_TOKEN) {
								get_brace(exp, data.tkqueue._Get_container(), false, 0, false);
								data.tkqueue.pop();
							}
							else {
								exp.emplace_back(data.tkqueue.back());
								data.tkqueue.pop();
								if (data.tkqueue.back().kind == LEFT_PAREN_TOKEN) {
									get_brace(exp, data.tkqueue._Get_container(), false, 0, true);
									//data.tkqueue.pop();
								}
							}
							token_t tkSEMI;
							tkSEMI.kind = SEMI_TOKEN;
							tkSEMI.str = ";";
							exp.emplace_back(tkSEMI);
							save_everything(CRBY_NORMAL);
							data.tkqueue._Get_container() = exp;
							ptoken_t ret = _Process();
							if (is_double_token(ret->kind))
								ret->value.int_v = int(ret->value.dd_v);
							else if (is_string_token(ret->kind))
								_Syntax_error("not opt is not for string");
							ret->value.int_v = bool(!ret->value.int_v);
							ret->kind = BOOL_NUMBER_TOKEN;
							unsave_everything(CRBY_NORMAL);
							return ret;
						}
						else if (data.tkqueue.back().kind != NAME_TOKEN)
							_Syntax_error("single opr not for rval");
					}
				
				isfront = true;
				single_op = ret->kind;
				goto ELSE;
			}
			else if (is_value_type(ret->kind)
				|| ret->kind == VOID_TOKEN
				|| ret->kind == REF_TOKEN) 
			{
				token_type_t ty = ret->kind;
				if (data.tkqueue.back().kind != NAME_TOKEN)
					throw _STD runtime_error("not define");
				string name = data.tkqueue.back().str;
				data.tkqueue.pop();
				if (data.tkqueue.back().kind == SEMI_TOKEN 
					|| data.tkqueue.back().kind == ASSIGN_OPERATOR_TOKEN) 
				{	//creating value
					if (ret->kind == VOID_TOKEN)
						throw _STD runtime_error("creating a void var!");
					base_variable_t m;
					m.type = ty;


					if (ret->kind == REF_TOKEN) {	//get ref
						//string name = data.tkqueue.back().str;
						//data.tkqueue.pop();
						if (data.tkqueue.back().kind != ASSIGN_OPERATOR_TOKEN)
							_Syntax_error("NULL REF NOT ALLOWED");
						data.tkqueue.pop();	//throw assign


						if (data.tkqueue.back().kind == NEW_TOKEN) {
							ptoken_t result = _Process();
							m.value.ppval.ptr = (base_variable_t *)(result->pval_ref);
						}
						else {
							bool iss = false;
							if (data.tkqueue.back().kind == GLOBAL_TOKEN) {
								iss = 1;
								data.tkqueue.pop();
							}
							if (data.tkqueue.back().kind != NAME_TOKEN)
								_Syntax_error("Bad ref!");
							string nnn = data.tkqueue.back().str;
							//data.tkqueue.pop();
							//if()
							if (data.tkqueue._Get_container()[1].kind == LEFT_PAREN_TOKEN) {
								ptoken_t result = _Process();
								if (result->kind != REF_TOKEN)
									_Syntax_error("REF refer to rvalue function");
								m.value.ppval.ptr = (base_variable_t *)(result->pval_ref);
							}
							else
							m.value.ppval.ptr = iss ? prun_env->get_env()->find_global_value(nnn) :
								prun_env->get_env()->find_value(nnn);
						}
					}
					int p = isstatic ? prun_env->get_env()->add_global_value(name, m, isconst)
						: prun_env->get_env()->add_value(name, m, isconst);
					if (p)throw _STD runtime_error("var existed");
					if (ty==REF_TOKEN)return nullptr;
				if (data.tkqueue.back().kind == ASSIGN_OPERATOR_TOKEN) {
						data.tkqueue.pop();
						prun_env->initial_every_value(name, isstatic, _Process());
						//isstatic ? prun_env->get_env()->add_global_value(name, data.tkqueue.back(), isconst)
						//	: prun_env->get_env()->add_value(name, data.tkqueue.back(), isconst);
					}
				}
				else if (data.tkqueue.back().kind == LEFT_PAREN_TOKEN) 
				{//create a function
					
					token_group_t code_body;
					par_list_type_t par_t_list;
					list<string> par_names;
					data.tkqueue.pop();
					bool tpars = false;//many pars
					int isconst = 0;
					while (data.tkqueue.back().kind != RIGHT_PAREN_TOKEN) {
						if (data.tkqueue.back().kind == CONST_TOKEN) {
							isconst = 1;
							data.tkqueue.pop();
							continue;
						}
						if (is_type_token(data.tkqueue.back().kind) || data.tkqueue.back().kind == REF_TOKEN)
						{
							par_t_list.emplace_back(data.tkqueue.back().kind, isconst);
							tpars = true;
							data.tkqueue.pop();
						}
						else _Syntax_error("wrong para");
						if (data.tkqueue.back().kind == NAME_TOKEN) {
							par_names.emplace_back(data.tkqueue.back().str);
							data.tkqueue.pop();
						}
						else _Syntax_error("wrong para");
						if(tpars && data.tkqueue.back().kind != RIGHT_PAREN_TOKEN)
							data.tkqueue.pop();
						isconst = 0;
					}
//auto SS = data.tkqueue.back();
					if(data.tkqueue.back().kind == RIGHT_PAREN_TOKEN)
						data.tkqueue.pop();
					/*
while (!data.tkqueue.empty()) {
	_STD cout << data.tkqueue.back().str;
	data.tkqueue.pop();
}*/
					if (data.tkqueue.back().kind != LEFT_BRACE_TOKEN)
						_Syntax_error("not a function");
					func_value_t fc_tmp;
					fc_tmp.ret_type = ty;
					fc_tmp.paras = Move(par_t_list);
					fc_tmp.func_itself.para_names = Move(par_names);

					get_brace(code_body, data.tkqueue._Get_container());
					//while
					fc_tmp.func_itself.codes_body = Move(code_body);
					isstatic ? prun_env->get_env()->add_global_func(name, fc_tmp) :
						prun_env->get_env()->add_func(name, fc_tmp);
				}
				else _Syntax_error("bad initial");
			}
			return ret;
		}
	}
	ptoken_t parse_primary_expression()
	{
		ptoken_t value;
		bool minus_flag = 0;
		ptoken_t ptoken = _Get_a_token();
		if (!ptoken) return nullptr;
		if (ptoken->kind == SUB_OPERATOR_TOKEN)	//��������
			minus_flag = 1;
		else
			_Unget_a_token(ptoken);

		ptoken = _Get_a_token();
		if (!ptoken) return nullptr;
		if (is_number_token_kind(ptoken->kind) ||
			(ptoken->kind == REF_TOKEN && ptoken->str != "ref") ||
			ptoken->kind == STRING_NUMBER_TOKEN) {
			if (minus_flag) {	//����
				if (is_integer_number_token_kind(ptoken->kind))
					ptoken->value.int_v = -(ptoken->value.int_v);
				else
					ptoken->value.dd_v = -(ptoken->value.dd_v);
			}
			return ptoken;
		}
		else if (ptoken->kind == LEFT_PAREN_TOKEN)	//parse dealing
		{
			value = _Process();
			ptoken = _Get_a_token();
			if (ptoken->kind != RIGHT_PAREN_TOKEN) {
				_Syntax_error("missing ')'");
			}
			return value;
		}
		//else if (ptoken->kind == RIGHT_PAREN_TOKEN && data.inpar == 1) {
		//	data.inpar = 0;
		//	return nullptr;
		//}
		else 
			_Unget_a_token(ptoken);


		return nullptr;
	}
	ptoken_t _Process() 
	{
		auto ret = _Process(token_sym_level_t::_16);
		return ret;
	}
	ptoken_t _Process(token_sym_level_t t)
	{	//start
		ptoken_t v1, v2, ptoken;
		//get first number(no XC)
		v1 = (t == token_sym_level_t::_1) ? parse_primary_expression() : _Process(dec_token_sym_level(t));
		if (!v1) return nullptr;
		if (data.have_return) return v1;
		while (1) {
			if (!(ptoken = _Get_a_token())) break;	//get op
			if (ptoken->kind == RIGHT_PAREN_TOKEN && data.inpar == 1 && data.tkqueue.back().kind == SEMI_TOKEN) {
				_Unget_a_token(ptoken); 
				//if (data.depar) {
				//	data.inpar--;
				//	data.depar = 0;
				//} 
				data.inpar = 0;
				break; 
			}
			if (token_sym_level(ptoken->kind) != t) {
				_Unget_a_token(ptoken);
				break;
			}
			
			//get second number(no XC)
			v2 = (t == token_sym_level_t::_1) ? parse_primary_expression() : _Process(dec_token_sym_level(t));
			if (!v2) break;	//nothing?
			try {
				v1 = allocate_sh<token_t>(_Token_calculate(v1, v2, ptoken->kind));
			}
			catch (string &st) {
				v1->kind = STRING_NUMBER_TOKEN;
				v1->str = Move(st);
			}
			//drop pref_val
		}
		return v1;
	}

	//calculate with type
	token_value_use_t _Token_calculate(ptoken_t _Left, ptoken_t _Right ,token_type_t op)
	{//
		token_value_use_t ret;
		_Left = ref_get_iden(_Left);
		_Right = ref_get_iden(_Right);
		//_Left
		if (is_string_token(_Left->kind) || is_string_token(_Right->kind)) {
			convert_to_string(_Left.get());
			convert_to_string(_Right.get());
			//ret.kind = BOOL_NUMBER_TOKEN;
			try {
				throw _Calculate(_Left->str, _Right->str, op);
			}
			catch (int i) {
				ret.value.int_v = i;
			}
		}
		else if (is_double_token(_Left->kind) || is_double_token(_Right->kind))
		{
			ret.kind = DD_NUMBER_TOKEN;
		/*	if(op == ASSIGN_OPERATOR_TOKEN)
			{ //write assign here

			}*/
			ret.value.dd_v = _Calculate((double)(is_int_token(_Left->kind) ? _Left->value.int_v : _Left->value.dd_v),
					(double)(is_int_token(_Right->kind) ? _Right->value.int_v : _Right->value.dd_v), op);
		}
		else
		{
			ret.kind = INT_NUMBER_TOKEN;
			ret.value.int_v = _Calculate(_Left->value.int_v, _Right->value.int_v, op);
		}
		if (is_compare_op(op)) {
			if (ret.kind == DD_NUMBER_TOKEN) ret.value.int_v = int(ret.value.dd_v);
			ret.kind = BOOL_NUMBER_TOKEN;
		}
		return ret;
	}

	template <typename _Ty>
	_Ty _Calculate(_Ty _Left, _Ty _Right, token_type_t op) {
		switch (op)
		{
		case MUL_OPERATOR_TOKEN:
			return _Left * _Right;
		case DIV_OPERATOR_TOKEN:
			return _Left / _Right;
		case ADD_OPERATOR_TOKEN:
			return _Left + _Right;
		case SUB_OPERATOR_TOKEN:
			return _Left - _Right;
		case POW_OPERATOR_TOKEN:
			return static_cast<_Ty>(pow(_Left, _Right));
		case EQUAL_TOKEN:
			return _Left == _Right;
		case C_OR_OPERATOR_TOKEN:
			return _Left || _Right;
		case C_AND_OPERATOR_TOKEN:
			return _Left && _Right;
		case NOT_EQUAL_TOKEN:
			return _Left != _Right;
		case HIGHER_TOKEN:
			return _Left > _Right;
		case LOWER_TOKEN:
			return _Left < _Right;
		case HE_TOKEN:
			return _Left >= _Right;
		case LE_TOKEN:
			return _Left <= _Right;
		default:
			_Syntax_error();
			break;
		}
	}
	template <>
	string _Calculate(string _Left, string _Right, token_type_t op) {
		switch (op)
		{
		case SUB_OPERATOR_TOKEN:
		case MUL_OPERATOR_TOKEN:
		case DIV_OPERATOR_TOKEN:
		case C_OR_OPERATOR_TOKEN:
		case C_AND_OPERATOR_TOKEN:
		case POW_OPERATOR_TOKEN:
			_Syntax_error("bad operator for string");
		case ADD_OPERATOR_TOKEN:
			return _Left + _Right;
		case EQUAL_TOKEN:
			if (_Left == _Right)
				throw 1;
			else
				throw 0;
		case NOT_EQUAL_TOKEN:
			if (_Left != _Right)
				throw 1;
			else
				throw 0;
		case HIGHER_TOKEN:
			if (_Left > _Right)
				throw 1;
			else
				throw 0;
		case LOWER_TOKEN:
			if (_Left < _Right)
				throw 1;
			else
				throw 0;
		case HE_TOKEN:
			if (_Left >= _Right)
				throw 1;
			else
				throw 0;
		case LE_TOKEN:
			if (_Left <= _Right)
				throw 1;
			else
				throw 0;
		default:
			_Syntax_error();
			break;
		}
	}
	void clear_is_look_ahead_exists() 
	{
		data.is_look_ahead_exists = 0;
	}
	[[noreturn]] void _Syntax_error() {
		throw _STD runtime_error(SYNTATIC_ANALYZER_EXCPTION_BEGINNING "Syntax error.\n");
	}
	[[noreturn]] void _Syntax_error(const char* str) {
		_STD stringstream ss;
		ss << SYNTATIC_ANALYZER_EXCPTION_BEGINNING "Syntax error: " << str << ".\n";
		throw _STD runtime_error(ss.str());
	}
	[[noreturn]] void _End_of_file() {
		throw _STD out_of_range("Reach end of file.");
	}
	//lexical_analyzer la;
	
	sa_data data;
	deq<sa_data> saver;
};
inline void Save_syn(syntatic_analyzer *psyn){
		psyn->save_everything(CRBY_FUNC);
}
inline void Unsave_syn(syntatic_analyzer *psyn) {
	psyn->unsave_everything(CRBY_FUNC);
}
//inline void _Include_file(const string& path) {

//}
inline typename syntatic_analyzer::ptoken_t Go_syn(token_group_t &m,
	syntatic_analyzer *psyn,
	int *for_going)
{
	if (m.size() == 0) return nullptr;
	m.shrink_to_fit();
	size_t loc = 0;
	syntatic_analyzer::ptoken_t ret;
	token_group_t p;
	
	while (true) {	//keep scaning
		bool is_exit_while = 0;
		while (m[loc].kind != SEMI_TOKEN)
		{
			if (loc >= m.size()) return nullptr;
			auto debug = m[loc].kind;
			switch (debug)
			{
			case END_OF_FILE_TOKEN:
				return nullptr;
			/*case INCLUDE_TOKEN:
				loc++;
				if (m[loc].kind != STRING_NUMBER_TOKEN)
					psyn->_Syntax_error("Bad Include.");
				//_Include_file(m[loc++].str);
				break;*/
			case LEFT_BRACE_TOKEN:
				loc+=get_paren(p, m.begin() + loc, m.end(), true, 0, true);
				is_exit_while = 1;
				break;
			case BREAK_TOKEN:
BREAK:			if (for_going)
					*for_going = 1;
				else
					throw _STD runtime_error("why break here?");
				return nullptr;
			case CONTINUE_TOKEN:
CONTI:			if (for_going)
					*for_going = 2;
				else
					throw _STD runtime_error("why continue here?");
				return nullptr;
			case RETURN_TOKEN:
				if (for_going) *for_going = 3;
				loc++;
				p.clear();
				loc += get_a_tk_line(p, m.begin() + loc, m.end());


				//ret = nullptr;
				psyn->save_everything(CRBY_NORMAL);
				ret = psyn->go(Move(p));
				psyn->unsave_everything(CRBY_NORMAL);
				psyn->data.have_return = 1;
				return ret;

			case FOR_TOKEN:
				p.clear();
				p.emplace_back(m[loc++]);
				loc += get_paren(p, m.begin() + loc, m.end());
				if (m[loc].kind == LEFT_BRACE_TOKEN)
					loc += get_paren(p, m.begin() + loc, m.end(), true, 0, true);
				else
					loc+=get_a_tk_line(p, m.begin() + loc, m.end());
				is_exit_while = 1;
				break;
			case IF_TOKEN:
IF:				p.clear();
				p.emplace_back(m[loc++]);
				loc += get_paren(p, m.begin() + loc, m.end());
				if (m[loc].kind == LEFT_BRACE_TOKEN)
					loc += get_paren(p, m.begin() + loc, m.end(), true, 0, true);
				else
					loc += get_a_tk_line(p, m.begin() + loc, m.end());
				if (m[loc].kind == ELSE_TOKEN) {
					p.emplace_back(m[loc++]);
					if (m[loc].kind == IF_TOKEN) goto IF;
					if (m[loc].kind == LEFT_BRACE_TOKEN)
						loc += get_paren(p, m.begin() + loc, m.end(), true, 0, true);
					else
						loc += get_a_tk_line(p, m.begin() + loc, m.end());
				}
				is_exit_while = 1;
				break;
			default:
				break;
			}
			if (is_exit_while) break;
			p.emplace_back(m[loc++]);
		}
		if (!is_exit_while) p.emplace_back(m[loc++]);	//add semi token
		add_eof_token(p);
//_STD for_each(p.begin(), p.end(), [=](token_t &a) {_STD cout << a.str; });
//_STD cout << _STD endl;
 		ret = psyn->go(Move(p));
		switch (psyn->data.have_return)
		{
		case 1:
			if (for_going)*for_going = 3;
			return ret;
		case 2:
			goto BREAK;
		case 3:
			goto CONTI;
		default:
			break;
		}
		if (is_exit_while && ret) break;
		p.clear();
		ret = nullptr;
	}
	return ret;
}
base_variable_t&& get_struct(token_group_t &grp, syntatic_analyzer *sa) {
	base_variable_t ret;
	sa->save_everything(CRBY_NORMAL);
	//remained
	sa->unsave_everything(CRBY_NORMAL);
	return Move(ret);
}
#endif
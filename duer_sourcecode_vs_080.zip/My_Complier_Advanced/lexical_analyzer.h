#pragma once
/*
	Lexical analyzer by Alvazu
	built in 2017.10

* Consult your license regarding permissions and restrictions.
* Ver 0.2.3
*/
#include <string>
#include <iostream>
#include <cctype>
#include <algorithm>
#include <sstream>
#include <stdexcept>
#include <map>
#include "ptr_se.h"
#include "token.h"
#include "deq.h"
#include "char_dispose.h"
#define LEXICAL_ANALYZER_EXCPTION_BEGINNING "\n** LEXICAL ANALYZER EXCEPTION\n\t"
using _STD string;
using _STD istream;
using _STD map;
class lexical_analyzer {
	//scanning status
	typedef enum {
		INITIAL_STATUS,
		IN_INT_PART_STATUS,
		DOT_STATUS,
		IN_FRAC_PART_STATUS,
		IN_NAME_STATUS,
		IN_STR_STATUS
	}lexer_status_t;
public:
	using size_type = string::size_type;
	//using ptoken_t = sh_ptr<token_t>;
	//token dealing type
	enum class Err_no_t {
		GENERAL,
		NAME_ERR,
		STRING_LONELY_QUO,
		WHY_DOT_HERE
	};
	using sym_pair_t = Pair<string, token_type_t>;
	using ptoken_t = sh_ptr<token_t>;

	lexical_analyzer() :
		is(&_STD cin), ptoken(nullptr)
	{	//construct by nothing
		_Initial_deq_of_sym();
		_Initial_map_of_name();
	}
	lexical_analyzer(istream &ii) :
		is(&ii), ptoken(nullptr)
	{	//construct by os
		_Initial_deq_of_sym();
		_Initial_map_of_name();
	}

	//get a token and move on, call this circulatingly
	ptoken_t get_token()
	{
		if (!is) return nullptr;
		_Move_on();
		return ptoken;
	}

	//just get token
	ptoken_t just_get_token() const
	{
		if (!is || !ptoken) return nullptr;
		return ptoken;
	}
	//set stream
	void set_content(istream &is)
	{
		clear();
		this->is = &is;
	}

	//clear context
	void clear()
	{
		ptoken = nullptr;
		is = nullptr;
	}
private:

	[[noreturn]] void _Syntax_error(Err_no_t err_no = Err_no_t::GENERAL) {
		_STD stringstream sst(LEXICAL_ANALYZER_EXCPTION_BEGINNING "Syntax error: ");
		sst << (int)err_no << " .\n";
		throw _STD runtime_error(sst.str());
	}
	[[noreturn]] void _Bad_char(int ch) {
		string ss;
		_STD stringstream sst(ss);
		sst << LEXICAL_ANALYZER_EXCPTION_BEGINNING "Bad character: '\\" << ch << "'.\n";
		throw _STD runtime_error(sst.str());
	}
	bool _Check_if(char current, char ch, token_type_t t)
	{
		if (ch == current) {
			ptoken->kind = t;
			return true;
		}
		return false;
	}
	//move on
	void _Move_on();
	//find if ch is a sym
	token_type_t _Scan_sym(char ch);
	//initial list of sym
	void _Initial_deq_of_sym();
	void _Initial_map_of_name();
	//temp data
	istream *is;
	ptoken_t ptoken;
	deq<sym_pair_t> deq_of_sym;
	map<string, token_type_t> map_of_inside_names;
	char_disposer _cd;
};

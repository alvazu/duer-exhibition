/*
* Copyright (c) by P.J. Plauger. All rights reserved.
* Consult your license regarding permissions and restrictions.
V6.50:0009 */

#pragma once
#include <type_traits>
#include "Type_converts.h"
template <typename _First, typename _Second> struct Pair {
	typedef Pair _Myt;
	template <typename _Uty1 = _First, typename _Uty2 = _Second,
		class = _STD enable_if_t<_STD is_default_constructible<_Uty1>::value &&
		_STD is_default_constructible<_Uty2>::value>> constexpr Pair() :first(), second()
	{
	}
	template<class _Uty1 = _First,
		class _Uty2 = _Second,
		class = _STD enable_if_t<_STD is_copy_constructible<_Uty1>::value
		&& _STD is_copy_constructible<_Uty2>::value>,
		_STD enable_if_t<_STD is_convertible<const _Uty1&, _Uty1>::value
		&& _STD is_convertible<const _Uty2&, _Uty2>::value, int> = 0>
		constexpr Pair(const _First& _Val1, const _Second& _Val2)
		: first(_Val1), second(_Val2)
	{	// construct from specified values
	}

	template<class _Uty1 = _First,
		class _Uty2 = _Second,
		class = _STD enable_if_t<_STD is_copy_constructible<_Uty1>::value
		&& _STD is_copy_constructible<_Uty2>::value>,
		_STD enable_if_t<!_STD is_convertible<const _Uty1&, _Uty1>::value
		|| !_STD is_convertible<const _Uty2&, _Uty2>::value, int> = 0>
		constexpr explicit Pair(const _First& _Val1, const _Second& _Val2)
		: first(_Val1), second(_Val2)
	{	// construct from specified values
	}


	Pair(const Pair&) = default;
	Pair(Pair&&) = default;

	template<class _Other1,
		class _Other2,
		class = _STD enable_if_t<_STD is_constructible<_First, const _Other1&>::value
		&& _STD is_constructible<_Second, const _Other2&>::value>,
		_STD enable_if_t<_STD is_convertible<const _Other1&, _First>::value
		&& _STD is_convertible<const _Other2&, _Second>::value, int> = 0>
		constexpr Pair(const Pair<_Other1, _Other2>& _Right)
		: first(_Right.first), second(_Right.second)
	{	// construct from compatible pair
	}

	template<class _Other1,
		class _Other2,
		class = _STD enable_if_t<_STD is_constructible<_First, const _Other1&>::value
		&& _STD is_constructible<_Second, const _Other2&>::value>,
		_STD enable_if_t<!_STD is_convertible<const _Other1&, _First>::value
		|| !_STD is_convertible<const _Other2&, _Second>::value, int> = 0>
		constexpr explicit Pair(const Pair<_Other1, _Other2>& _Right)
		: first(_Right.first), second(_Right.second)
	{	// construct from compatible pair
	}

	template<class _Other1,
		class _Other2>
		_Myt& operator=(const Pair<_Other1, _Other2>& _Right)
	{	// assign from compatible pair
		first = _Right.first;
		second = _Right.second;
		return (*this);
	}

	template<class _Other1,
		class _Other2,
		class = _STD enable_if_t<_STD is_constructible<_First, _Other1>::value
		&& _STD is_constructible<_Second, _Other2>::value>,
		_STD enable_if_t<_STD is_convertible<_Other1, _First>::value
		&& _STD is_convertible<_Other2, _Second>::value, int> = 0>
		constexpr Pair(_Other1&& _Val1, _Other2&& _Val2)
		noexcept(_STD is_nothrow_constructible<_First, _Other1>::value
			&& _STD is_nothrow_constructible<_Second, _Other2>::value)
		: first(Forward<_Other1>(_Val1)),
		second(Forward<_Other2>(_Val2))
	{	// construct from moved values
	}

	template<class _Other1,
		class _Other2,
		class = _STD enable_if_t<_STD is_constructible<_First, _Other1>::value
		&& _STD is_constructible<_Second, _Other2>::value>,
		_STD enable_if_t<!_STD is_convertible<_Other1, _First>::value
		|| !_STD is_convertible<_Other2, _Second>::value, int> = 0>
		constexpr explicit Pair(Pair<_Other1, _Other2>&& _Right)
		noexcept(_STD is_nothrow_constructible<_First, _Other1>::value
			&& _STD is_nothrow_constructible<_Second, _Other2>::value)
		: first(Forward<_Other1>(_Right.first)),
		second(Forward<_Other2>(_Right.second))
	{	// construct from moved compatible pair
	}
	/*
	template <class _Uty1,
	class _Uty2,
	class=_STD enable_if_t<_STD is_constructible<_First,_Uty
	*/
	void swap(_Myt & _Right) noexcept(_STD _Is_nothrow_swappable<_First>::value
		&& _STD _Is_nothrow_swappable<_Second>::value) {
		if (this != _STD addressof(_Right)) {
			_STD swap(first, _Right.first);
			_STD swap(second, _Right.second);
		}
	}
public:
	_First first;
	_Second second;

};
template <typename _Ty1, typename _Ty2> inline
bool operator==(Pair<_Ty1, _Ty2> &_Left,
	Pair<_Ty1, _Ty2> &_Right)
{
	return _Left.first == _Right.first 
		&& _Left.second == _Right.second;
}
/*deq build 2016 rebuild in 201709

custom deque for everyone~

* Powered by Alvazu,
* Consult your license regarding permissions and restrictions.
* Ver 1.1.2
*/
#pragma once
#include "alloc.h"
#include "pair.h"
#include <memory>
#include "Type_converts.h"
#define _SCL_SECURE_NO_WARNING
#pragma warning(push)
#pragma warning(disable:4996)
#pragma push_macro("new")
#undef new
template <typename _Ty, typename _Alloc = Allocator<_Ty>> class deq {
	using pointer = _Ty*;
	using rvalue = _Ty &&;
	using _Myt = deq<_Ty>;
	using ppair = Pair<pointer, pointer>;
public:
	using reference = _Ty &;
	using const_reference = const _Ty &;
	using value_type = _Ty;
	using size_type = size_t;
	using diff_type = size_t;
	using iterator = pointer;
	using const_iterator = const pointer;
	using alloc_t = _Alloc;
	deq()
		//:head(nullptr), first_elem(nullptr), first_free(nullptr), cap(0)
	{		//construct by nullptr
		initial_one();
	}
	template <typename _Uty,
		class = _STD enable_if_t<_STD is_constructible<_Ty, _Uty>::value>,
		_STD enable_if_t<_STD is_convertible<const _Uty&, _Ty>::value, int> = 0>
		deq(const _Uty & t)
	{		//construct by a specified value
		initial_one();
		alloc.construct(first_free++, t);
	}
	template <typename _Uty,
		class = _STD enable_if_t<_STD is_constructible<_Ty, _Uty>::value>,
		_STD enable_if_t<!_STD is_convertible<const _Uty&, _Ty>::value, int> = 0>
		explicit deq(const _Uty & t)
	{	//construct by a specified value
		initial_one();
		alloc.construct(first_free++, t);
	}
	template <typename _Uty,
		class = _STD enable_if_t<_STD is_constructible<_Ty, _Uty>::value>,
		_STD enable_if_t<_STD is_convertible<_Uty, _Ty>::value, int> = 0 >
		deq(_Uty && t)
	{		//construct by a movable value
		initial_one();
		alloc.construct(first_free++, Forward<_Uty>(t));
	}
	template <typename _Uty,
		class = _STD enable_if_t<_STD is_constructible<_Ty, _Uty>::value>,
		_STD enable_if_t<!_STD is_convertible<_Uty, _Ty>::value, int> = 0 >
		explicit deq(_Uty && t)
	{		//construct by a movable value
		initial_one();
		alloc.construct(first_free++, Forward<_Uty>(t));
	}
	template <typename _Uty,
		class = _STD enable_if_t<_STD is_constructible<_Ty, _Uty>::value>>
		deq(_STD initializer_list<_Uty> l)
	{		//construct by a list
		is_sub_deq = false;
		auto p = reallocate(l.size());
		first_free = p.first;
		_STD for_each(l.begin(), l.end(), [&](const _Uty & it)->void {
			alloc.construct(first_free++, it);
		});
		head = first_elem = p.first;
		cap = l.size();
	}

	deq(const _Myt & d)
	{ 		//construct by a deq
		is_sub_deq = 0;
		copy_n(d);
	}
	deq(_Myt && d) _NOEXCEPT
	{ //move from DEQ
		is_sub_deq = 0;
		head = d.head;
		first_elem = d.first_elem;
		first_free = d.first_free;
		cap = d.cap;
		d.head = d.first_elem = d.first_free = nullptr;
		d.cap = 0;
	}
	~deq()
	{	//leave deq
		free();
	}
	_Myt & operator=(const _Myt & v) &
	{	//assign with deq
		free();
		is_sub_deq = v.is_sub_deq;
		copy_n(v);
		return *this;
	}
	_Myt & operator=(_Myt && v) &
	{	//assign with deq
		if(!this->empty())
			free();
		is_sub_deq = v.is_sub_deq;
		head = v.head;
		first_elem = v.first_elem;
		first_free = v.first_free;
		cap = v.cap;
		v.head = v.first_elem = v.first_free = nullptr;
		v.cap = 0;
		return *this;
	}
	void operator=(_STD nullptr_t)
	{ 	//leave deq
		free();
	}

	void push_back(const_reference v)
	{	//add element to back
		chk_n_back();
		emplace_back(v);
	}
	void push_front(const_reference v)
	{	//add element to front
		chk_n_front();
		emplace_front(v);
	}
	void push_back(rvalue v)
	{	//add element to back
		chk_n_back();
		emplace_back(Move(v));
	}
	void push_front(rvalue v)
	{	//add element to front
		chk_n_front();
		emplace_front(Move(v));
	}
	template <class... _Valty> inline void emplace_back(_Valty && ... _Val)
	{	//set element to back
		chk_n_back();
		emplace(first_free++, Forward<_Valty>(_Val)...);
	}
	template <class... _Valty> inline void emplace_front(_Valty && ... _Val)
	{	//set element to front
		chk_n_front();
		emplace(--first_elem, Forward<_Valty>(_Val)...);
	}
	template <class... _Valty> inline void emplace(size_type _where, _Valty&& ... _Val) noexcept
	{	//set element
		emplace(first_elem + _where, Forward<_Valty>(_Val)...);
	}
	template <class... _Valty> inline void emplace(pointer _where, _Valty&& ... _Val)
	{	//set element
		(this->alloc).construct(_STD _Unfancy(_where), Forward<_Valty>(_Val)...);
	}
	void swap(_Myt & v) & _NOEXCEPT
	{	//just swap deq and deq
		using _STD swap;
		swap(v.head, head);
		swap(v.first_elem, first_elem);
		swap(v.first_free, first_free);
		swap(v.cap, cap);
	}
	void shrink_to_fit()
	{	//deduce space using to fit
		ppair p = _Move_data_and_clean_former_space(size(), 0);
		cap = p.second - p.first;
		head = first_elem = p.first;
		first_free = head + cap;
	}
	rvalue pop_front()
	{ //pop element from front
		return Move(*first_elem++);
	}
	rvalue pop_back()
	{ //pop element from back
		return Move(*--first_free);
	}
	reference front() const
	{ //get element from front
		return *first_elem;
	}
	reference back() const
	{ //get element from back
		return *(first_free - 1);
	}
	iterator begin()
	{ //get iterator of the beginning
		return first_elem;
	}
	iterator end()
	{ //get iterator of the end
		return first_free;
	}
	const_iterator begin() const
	{ //get const iterator of the beginning
		return first_elem;
	}
	const_iterator end() const
	{ //get const iterator of the end
		return first_free;
	}
	const_iterator cbegin() const
	{ //get const iterator of the beginning
		return first_elem;
	}
	const_iterator cend() const
	{ //get const iterator of the end
		return first_free;
	}
	bool empty() const
	{ //check if empty
		return size() == 0;
	}
	void clear()
	{ //cleat the whole deq
		free();
	}
	bool null() const
	{ //check if empty
		return head == nullptr;
	}
	size_type size() const
	{ //get the number of elements
		return first_free - first_elem;
	}
	size_type capacity() const
	{ //get the capacity of elements
		return cap;
	}
	reference operator[](size_type s)const & noexcept
	{ //get the element by order
		return *(first_elem + s);
	}
	reference at(size_type s)const &
	{ //get the element by order
		if (s > size())
			throw _STD out_of_range("deq out of range");
		return *(first_elem + s);
	}
private:
	template <typename iter>
	void copy_n(iter begin, iter end)
	{	//copy but not clean former
		head = alloc.allocate(end - begin);
		first_elem = head;
		first_free = _STD uninitialized_copy(begin, end, head);
		cap = end - begin;
	}

	void copy_n(const _Myt & v)
	{ //copy but not clean former
		copy_n(v.first_elem, v.first_free);
	}
	void free()
	{	//free all
		//if (is_sub_deq)return;
		if (head) {
			for (auto p = first_free; p != first_elem;)
				alloc.destroy(--p);
			alloc.deallocate(head, cap);
			head = first_elem = first_free = nullptr;
			cap = 0;
		}
	}
	void initial_one()
	{	//initial deque as a blank one, not nullptr
		is_sub_deq = 0;
		head = alloc.allocate(3);
		cap = 3;
		first_elem = first_free = head + 1;
	}
	ppair reallocate(size_type sz)
	{	//reallocate with( prbbly ) exception
		try {
			pointer p = alloc.allocate(sz);
			return { p,p + sz };
		}
		catch (...) {
			_STD cerr << "memory error";
			throw;
		}
		return { nullptr,nullptr };
	}

	void chk_n_front()
	{	//check if deque's head is full
		if (chk_if_null() && first_elem == head) {
			size_type old_size = size();
			size_type new_size = cap * 2;
			size_type back = cap - (first_free - head);
			size_type new_start = new_size - size() - back;
			auto p = _Move_data_and_clean_former_space(new_size, new_start);
			head = p.first;
			cap = new_size;
			first_elem = p.first + new_start;
			first_free = first_elem + old_size;
		}
	}

	void chk_n_back()
	{	//check if deque's back is full
		if (chk_if_null() && first_free == head + cap) {
			size_type old_size = size();
			size_type new_size = cap * 2;
			size_type new_start = first_elem - head;
			auto p = _Move_data_and_clean_former_space(new_size, new_start);
			head = p.first;
			cap = new_size;
			first_elem = p.first + new_start;
			first_free = first_elem + old_size;
		}
	}
	bool chk_if_null()
	{		//check if dequq is nullptr
		if (!head) {
			initial_one();
			return false;
		}
		return true;
	}
	template <typename = _STD enable_if_t<!_STD is_move_constructible<_Ty>::value>>
	ppair && _Move_data_and_clean_former_space(size_type new_size,
		size_type begin)
	{	//move all the data and settle space
		ppair p = reallocate(new_size);
		_STD uninitialized_copy(first_elem, first_free, p.first + begin);
		free();
		return Move(p);
	}
	template <typename _Uty = _STD enable_if<_STD is_move_constructible<_Ty>::value, ppair>::type>
	_Uty && _Move_data_and_clean_former_space(size_type new_size,
		size_type begin)
	{	//move all the data and settle space
		ppair p = reallocate(new_size);
		size_type counter = 0;
		_STD for_each(first_elem, first_free, [&](reference now) {
			alloc.construct(p.first + begin + counter++, Move(now));
			alloc.destroy(&now);
		});
		alloc.deallocate(head, cap);
		return Move(p);
	}


private:
	bool is_sub_deq;
	alloc_t alloc;
	pointer head;
	pointer first_elem;
	pointer first_free;
	size_type cap;
};
template <typename _Ty,
	class _Alloc> inline
	bool operator==(const deq<_Ty, _Alloc> & _Left,
		const deq<_Ty, _Alloc> & _Right)
{
	return (_Left.size() == _Right.size()
		&& _STD equal(_Left.begin(), _Left.end(), _Right.begin()));
}
template<class _Ty,
	class _Alloc> inline
	bool operator<(const deq<_Ty, _Alloc> & _Left,
		const deq<_Ty, _Alloc> & _Right)
{	// test if _Left < _Right for deq
	return (_STD lexicographical_compare(_Left.begin(), _Left.end(),
		_Right.begin(), _Right.end()));
}
template<class _Ty,
	class _Alloc> inline
	bool operator>(const deq<_Ty, _Alloc> & _Left,
		const deq<_Ty, _Alloc> & _Right)
{	// test if _Left > _Right for deq
	return (_Right < _Left);
}
#pragma pop_macro("new")
#pragma warning(pop)
#undef _SCL_SECURE_NO_WARNING
#pragma once

#include <algorithm>
#include <ctime>
#include <cstdlib>
#include "lang_run.h"
#include "syntactic_analyzer.h"
#include "lang_type_convert.h"
//class lang_runner;
class syntatic_analyzer;
void Save_syn(syntatic_analyzer *psyn);
void Unsave_syn(syntatic_analyzer *psyn);
typename sh_ptr<token_t> Go_syn(token_group_t &m, syntatic_analyzer *psyn,int *);

class lang_runner {
public:
	using ptoken_t = sh_ptr<token_t>;
	lang_runner(token_group_t &&pdeq, syntatic_analyzer *syn):
		token_deq(Forward<token_group_t>(pdeq)),psyn(syn){}
	void go();
	ptoken_t get_value(syn_connect_value_t &&, bool isglobal, token_type_t dowhat = BAD_TOKEN, bool isfront = 0);
	ptoken_t call_a_function(syn_connect_value_t &&, bool);	//reuse a syn
	void modify_value(const string &, bool, ptoken_t);
	run_environment *get_env() { return &environment; }
	void add_new_env_cir() {
		environment.add_new_env();
	}
	//void do_a_circulate(const token_group_t &, const token_group_t &, const token_group_t &);
	int break_out() {
		return environment.delete_current_env(run_environment::BREAK_DEL);
	}
	int continue_in() {
		return environment.delete_current_env(run_environment::CONTINUE_DEL);
	}
	void add_new_env_if() {
		environment.add_new_env(false, true);
	}
	int del_env_if() {
		return environment.delete_current_env(run_environment::JUSTONE_DEL);
	}
	void exit_prc(ptoken_t t) {
		_STD cout << "EXIT PROCESS: ";
		if (!t.available()) {
			_STD cout << "__void";
		}
		bool isref = false;
	SWI:
		
		switch (t->kind)
		{
		case STRING_NUMBER_TOKEN:
		case STRING_TOKEN:
			_STD cout << '"' << t->str << '"';
			break;
		case CHAR_NUMBER_TOKEN:
		case CHAR_TOKEN:
			_STD cout << '\'' << char(t->value.int_v) << '\'';
			break;
		case BOOL_NUMBER_TOKEN:
		case BOOL_TOKEN:
			if (t->value.int_v)
				_STD cout << "true";
			else
				_STD cout << "false";
			break;
		case INT_NUMBER_TOKEN:
		case INT_TOKEN:
			_STD cout << t->value.int_v;
			break;
		case DD_NUMBER_TOKEN:
		case DOUBLE_TOKEN:
			_STD cout << t->value.dd_v;
			break;
		case REF_TOKEN:
			t = ref_get_iden(t);
			_STD cout << "REF to " << get_type_name_str(t->kind) << "(";
			isref = true;
			//t->kind=
			goto SWI;
			break;
		default:
			break;
		}
		if (isref) _STD cout << ")";
		_STD cout << _STD endl;
	}
	base_variable_t * add_value_to_heap(token_type_t T, ptoken_t res, bool isconst ,bool isstatic) {
		if (!res.available())
			res = allocate_sh<token_t>(0);
		if (res->kind == VOID_TOKEN)
			throw _STD runtime_error("NO RETURN VALUE");
		vars_type_convert_for_function_calling(res.get(), T);
		//get a rand string
		/*
MAKE_R:
		srand(unsigned(time(0)));
		
		string rname = _convert_to_string(rand());
		try { 
			environment.pHEAP->values.at(rname);
			goto MAKE_R;
		}
		catch (_STD exception &) {
			
		}*/
		//string rname = "1";
		base_variable_t tmp(res->get_use_t());
		//tmp.value.ppval.ptr = res.get()->get_use_t;
		tmp.type = number_to_type(tmp.type);
		if (is_string_token(res->kind))tmp.value.sval = res->str;
		environment.pHEAP->heap_values.emplace_back(tmp);
		//((*x).second)
		return &(environment.pHEAP->heap_values.back());//&((*x).second);//(environment.pHEAP->values[rname]);
		//base_variable_t add;
		//add.isconst = isconst;
		//add.type = REF_TOKEN;
		//add.value.ppval.ptr = pto;
		//if (isstatic)
		//	environment.add_global_value(name, add, isconst);
		//else
		//	environment.add_value(name, add, isconst);
		//return pto;
		//environment.pHEAP->
	}
	//void add_ref(token_group_t &&tks,const string &name,)
	void initial_every_value(const string & name, bool isglobal, ptoken_t res);
	int _import(const string&, bool);
private:
	list<string> impt_file;
	run_environment environment;
	syntatic_analyzer *psyn;
	token_group_t token_deq;
};
void lang_runner::go() {
	if (token_deq.size() == 0) return;
	try {
		syn_connect_value_t tmp;
		tmp.name = "main";
		tmp.is_func = true;
		
		//first_deal();
		Go_syn(token_deq, psyn, nullptr);
		auto tt = call_a_function(Move(tmp), true);
		exit_prc(tt);
	}
	catch (_STD exception &e) {
		_STD cout << e.what();
		//throw;
	}
}

lang_runner::ptoken_t lang_runner::call_a_function(syn_connect_value_t &&v, bool isglobal)
{
	base_variable_t *l;
	par_list_type_t par_t_tmp;
	_STD for_each(v.value.cbegin(), v.value.cend(), [&](const Pair<token_value_use_t,int> &t) {
		//t.first.kind
		par_t_tmp.emplace_back(number_to_type(t.first.kind), t.second);
	});
	func_value_t *pfunc = isglobal ? environment.find_global_func(v.name, par_t_tmp)
		: environment.find_func(v.name, par_t_tmp);
	if (!pfunc)
		throw _STD runtime_error("func not found");
	Save_syn(psyn);
	//
	environment.add_new_env(true);
	//add paras
	auto kk_type = par_t_tmp.begin();
	_STD for_each(v.value.begin(), v.value.end(), [&](Pair<token_value_use_t, int> &t) {
		//t.first.kind
		t.first.kind = kk_type++->first;
		//par_t_tmp.emplace_back(number_to_type(t.first.kind), t.second);
	});
	auto sp = pfunc->func_itself.para_names.begin();
	auto sp_end = pfunc->func_itself.para_names.end();
	auto vp = v.value.begin();
	auto vp_end = v.value.end();
	auto cp = pfunc->paras.begin();
	auto cp_end = pfunc->paras.end();//error.type should be decided by function

	while (sp != sp_end && vp != vp_end) {
		if (!is_string_token(vp->first.kind))
			environment.add_value(*(sp++), (vp->first), (bool)(cp->second));
		else {
			//string *m;
			environment.add_value(*(sp++), (string *)(vp->first.pval_ref), (bool)(cp->second));
			delete (string *)(vp->first.pval_ref);
		}
		vp++;
		cp++;
	}
	ptoken_t rett = Go_syn(pfunc->func_itself.codes_body, psyn, nullptr);
	if (rett.available()) {
		if(rett->kind != VOID_TOKEN)
			vars_type_convert_for_function_calling(rett.get(), pfunc->ret_type);
		else rett = nullptr;
	}
	else rett = nullptr;
	Unsave_syn(psyn);
	environment.delete_current_env(run_environment::RETURN_DEL);
	return rett;
}
void lang_runner::modify_value(const string & name, bool isglobal, ptoken_t res)
{
	base_variable_t * ret = isglobal ? environment.find_global_value(name) 
		: environment.find_value(name);
	if (!ret) throw _STD runtime_error("cannot find var");

	if (res->kind == REF_TOKEN && ret->type == REF_TOKEN) 
	{	//ref=ref
		ret->value.ppval.ptr = (base_variable_t *)(res->pval_ref);
		return;
	}
	auto reff = ref_get_iden(ret);
	bool isconst = reff.second;
	if (isconst) throw _STD runtime_error("try to modify const var");
	else	set_value(reff.first, res);
}
void lang_runner::initial_every_value(const string & name, bool isglobal, ptoken_t res)
{
	base_variable_t * ret = isglobal ? environment.find_global_value(name)
		: environment.find_value(name);
	if (ret->type == REF_TOKEN)
	{	///ref=ref
		//if(ret->type == REF_TOKEN)
		if (!res.available())return;
		if (res->pval_ref != nullptr)
			ret->value.ppval.ptr = (base_variable_t *)(res->pval_ref);
		else
			throw _STD runtime_error("cannot initial ref by rvalue");
		//else
		//{//ref = var
			//ret->value.ppval.ptr = res->pval_ref;
		//}
		return ;
	}
	set_value(ret, res);
}
lang_runner::ptoken_t lang_runner::get_value(syn_connect_value_t &&v,
	bool isglobal,
	token_type_t dowhat,
	bool isfront)
{
	bool isref = 0;
	base_variable_t * ret = isglobal ? environment.find_global_value(v.name) : environment.find_value(v.name);
	if (!ret) throw _STD runtime_error(string("no such a value:") + v.name);
	ptoken_t pret;
	base_variable_t * save = ret;
	auto reff = ref_get_iden(ret);		//reff has the identity
	if (ret->type == REF_TOKEN)
		isref = 1;
	bool isconst = reff.second;

	if (dowhat != BAD_TOKEN) { //have single-operator, return a NUMBER_TOKEN
		
		ret = reff.first;	//ret is identity
		pret = allocate_sh<token_t>(ret->value.nval);	//pret has the number
		pret->kind = type_to_number(ret->type);			//pret has the type of identity
		
		if (!is_number_type_token_kind(ret->type))
			throw _STD runtime_error("cannot be used for a not-number type");
		
		switch (dowhat)
		{
		case NOT_OPERATOR_TOKEN:
			if (!isfront)
				throw _STD runtime_error("not operator should be before the var");
			if (is_integer_number_token_kind(pret->kind)) pret->value.int_v = (int)!(pret->value.int_v);
			else if (pret->kind == DD_NUMBER_TOKEN) pret->value.dd_v = (double)!(pret->value.dd_v);
			pret->kind = BOOL_NUMBER_TOKEN;
			break;
		case INCR_OPERATOR_TOKEN:

			if (isconst) throw _STD runtime_error("try to modify const var");
			if (is_integer_type_token_kind(ret->type)) ret->value.nval.int_v++;
			else ret->value.nval.dd_v++;
			if (isfront)
			{
				if (is_integer_number_token_kind(pret->kind)) pret->value.int_v++;
				else if (pret->kind == DD_NUMBER_TOKEN) pret->value.dd_v++;
				auto ty = number_to_type(pret->kind);
				pret->kind = type_to_number(pret->kind);
				vars_type_convert_for_function_calling(pret.get(), ty, true);
			}
			break;
		case DECR_OPERATOR_TOKEN:
			if (isconst) throw _STD runtime_error("try to modify const var");
			if (is_integer_type_token_kind(ret->type)) ret->value.nval.int_v--;
			else ret->value.nval.dd_v--;
			if (isfront)
			{
				auto ty = number_to_type(pret->kind);
				pret->kind = INT_NUMBER_TOKEN;
				vars_type_convert_for_function_calling(pret.get(), ty, true);
				if (is_integer_number_token_kind(pret->kind)) pret->value.int_v--;
				else if (pret->kind == DD_NUMBER_TOKEN) pret->value.dd_v--;
				
			}
			break;
		default:
			break;
		}
		pret->pval_ref = save;
	}
	else {	//nothing: return ref or itself
		if (isref) {
			pret = allocate_sh<token_t>(ret->value.ppval.ptr);	//pret has the ref
			pret->kind = REF_TOKEN;	//pret has REF_TOKEN
		}
		else {
		
			if (is_string_token(save->type))
				pret = allocate_sh<token_t>(Move(ret->value.sval));
			else
				pret = allocate_sh<token_t>(ret->value.nval);	//pret has the number
			pret->kind = type_to_number(ret->type);			//pret has the type of identity
			pret->pval_ref = save;
		}
		
	}
	
	vars_type_convert_for_function_calling(pret.get(), ret->type, true);
	
	return pret;
}
int lang_runner::_import(const string& file_path,bool isunique)
{	//import a file

	if (isunique) {
		if (_STD find(impt_file.cbegin(),
			impt_file.cend(),
			file_path) != impt_file.cend())
			return -1;
	}
	_STD ifstream file(file_path);
	if (!file.is_open())
		throw _STD runtime_error(string("fail to open file: ") + file_path);
	token_group_t all_the_tokens;
	lexical_analyzer la(file);
	while (1) {
		token_t token = *la.get_token();
		if (token.kind != COMMENT_TOKEN
			&& token.kind != END_OF_LINE_TOKEN) {
			all_the_tokens.emplace_back(token);
		}
		if (token.kind == END_OF_FILE_TOKEN) break;
	}

	Go_syn(all_the_tokens, psyn, nullptr);
	return 0;
}

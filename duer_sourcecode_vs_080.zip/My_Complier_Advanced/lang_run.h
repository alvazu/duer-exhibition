#pragma once
#include <map>
#include <string>
#include <list>
#include <algorithm>
#include <tuple>
#include "ptr_se.h"
#include "token.h"
#include "pair.h"
using _STD map;
using _STD list;
using _STD string;
using _STD multimap;

typedef token_type_t variable_type_t;
typedef Pair<token_type_t, int> par_list_elem;
typedef list<par_list_elem> par_list_type_t;
bool operator==(const par_list_type_t &_Left,
	const par_list_type_t &_Right) {
	if (_Left.size() != _Right.size())return false;
	try {
		auto now2 = _Left.cbegin();
		_STD for_each(_Right.cbegin(), _Right.cend(),
			[&now2](const par_list_elem &n) {
			if (n.first != now2->first)
				throw _STD runtime_error("");
			++now2;
		});
		return true;
	}
	catch (_STD runtime_error&) {
		return false;
	}
}
struct syn_connect_value_t {	//syntactic_return value
	syn_connect_value_t()
		:is_func(false){}
	syn_connect_value_t(syn_connect_value_t &&v)
		:is_func(v.is_func),name(Move(v.name)),value(Move(v.value)){}
	bool is_func;
	string name;
	list<Pair<token_value_use_t, int>> value;
};
struct func_itself {
	//map<string, variable_type_t> para_list;
	list<string> para_names;
	token_group_t codes_body;
};
struct func_value_t {	//function sign
	variable_type_t ret_type;
	par_list_type_t paras;
	func_itself func_itself;
};
class base_variable_t;
class current_environment_t;
struct ref_value_t {
	//typedef sh_ptr<current_environment_t> pcurrent_env_t;
	base_variable_t *ptr;
	//pcurrent_env_t pt;
	//variable_type_t ptype;
};
class myclass_instance_t;
typedef struct {
	token_value_t nval;
	string sval;
	func_value_t pfval;
	ref_value_t ppval;
	sh_ptr<myclass_instance_t> pclval;
}variable_value_t;
class base_variable_t {
public:
	base_variable_t():isconst(false) {}
	bool isconst;
	//string name;
	variable_type_t type;
	string class_type;
	variable_value_t value;
	base_variable_t &operator=(base_variable_t &var) {
		//name = var.name;
		class_type = var.class_type;
		type = var.type;
		//set_value_t(&value, &(var.value));
		value = var.value;
		if(var.value.pclval.available())
			value.pclval = allocate_sh<myclass_instance_t>(*(var.value.pclval));
		isconst = var.isconst;
		return *this;
	}
	base_variable_t(const token_value_use_t &t) {
		type = t.kind;
		value.nval = t.value;
		value.ppval.ptr = (base_variable_t*)(t.pval_ref);
		//value.pclval = t.value.
		isconst = 0;
	}
	base_variable_t(string *t) {
		type = STRING_TOKEN;
		value.sval = Move(*t);
		isconst = 0;
	}
	base_variable_t(const base_variable_t &t) {
		type = t.type;
		isconst = t.isconst;
		if (is_string_token(type)) {
			value.sval = Move(t.value.sval);
			return;
		}
		value.nval = t.value.nval;
		value.ppval.ptr = t.value.ppval.ptr;
		
	}
	base_variable_t(base_variable_t &&t) {
		type = t.type;
		value.nval = Forward<token_value_t>(t.value.nval);
		value.ppval.ptr = t.value.ppval.ptr;
		value.pclval = t.value.pclval;
		isconst = t.isconst;
	}
private:
	void set_value_t(variable_value_t *_Dest, variable_value_t *_Source) {
		memcpy(_Dest, _Source, sizeof(variable_value_t));
	}
	//~base_variable_t() {}
};
/*
class current_environment_t;
class class_define_t {
//for define
public:
	enum class CLASS_PRIORITY {
		PUBLIC_TH,
		PROTECTED_TH,
		PRIVATE_TH
	};
	using func_prio_t = Pair<CLASS_PRIORITY, func_value_t>;
	///*tuple<is_const, type_name, type_name(if it is a class number) , var_name>//
	//using dy_var = deq<_STD tuple<CLASS_PRIORITY, bool, variable_type_t, string, string>>;
	class_define_t(const string &name)
		:name(name)
	{
	}
	class_define_t(string &&name)
		:name(Forward<string>(name)) 
	{
		
	}
	bool is_dynamic_name(const string &name)const {
		if (is_exactly_name(name))
			return true;
		try {
			extends_class.at(name);
			return true;
		}
		catch (_STD out_of_range &) {
			return false;
		}
	}
	bool is_exactly_name(const string &name)const {
		return this->name == name;
	}
	
	Pair<CLASS_PRIORITY, func_value_t*> _find_function(

		const string &name,
		bool spec_static = false)
	{
		try {

		}
		catch () {

		}
	}
private:
	string name;
	//map<string, class_define_t*> extends_class;

	//multimap<string, func_prio_t> inner_funcs;
	//multimap<string, func_prio_t> static_funcs;
	
	deq<_STD tuple<string, variable_type_t, string>> inner_vars;
	//map<string, Pair<CLASS_PRIORITY, base_variable_t>> static_vars;
};
class class_instance {
	class_define_t *def;
	map<string, base_variable_t> inner_vars_inst;
	deq<class_instance*> extends;
};
*/
class myclass_define_t {
public:
	//isconst, ... ,classname
	using myclass_type_info = _STD tuple<int, variable_type_t, string>;
	using inner_var_t = map<string, myclass_type_info>;
	myclass_define_t(const string &name,
						inner_var_t &&mapp,
						deq<string> &&seq)
		:name(name),
		inner_vars(Forward<inner_var_t>(mapp)),
		seq(Forward<deq<string>>(seq))
	{
	}
	myclass_define_t(myclass_define_t && myc) {
		inner_vars = Move(myc.inner_vars);
		name = Move(myc.name);
	}

	myclass_type_info if_inner_var_exists(const string& name)noexcept {
		try {
			return inner_vars.at(name);
		}
		catch (_STD out_of_range &) {
			return _STD make_tuple<int, variable_type_t, string>(0, BAD_TOKEN, nullptr);
		}
	}
private:
	inner_var_t inner_vars;
	deq<string> seq;
	string name;
};
class myclass_instance_t {
public:
	myclass_instance_t(myclass_define_t *def):
		def(def)
	{}
	myclass_instance_t(myclass_instance_t&& mi):
		base_vars(Move(mi.base_vars)),
		def(mi.def)
	{}
	myclass_instance_t(const myclass_instance_t& mi) :
		base_vars(mi.base_vars),
		def(mi.def)
	{}
	void setBase_vars(map<string, base_variable_t>&&mp) {
		base_vars = Forward<map<string, base_variable_t>>(mp);
	}
	map<string, base_variable_t>& getBase_vars() {
		return base_vars;
	}
private:
	map<string, base_variable_t> base_vars;
	//map<string, myclass_instance_t*> cls_vars;
	myclass_define_t *def;
};
class current_environment_t {
public:
	typedef sh_ptr<current_environment_t> pcurrent_env_t;
	friend class run_environment;
	friend class lang_runner;
	pcurrent_env_t last;
	pcurrent_env_t outer;
	//pcurrent_env_t cir_outer;
	enum curr_type{
		BIGBOTTLE_CURR,	//GLOBAL
		FUNC_CURR,
		CIR_CURR,
		ORDIN_CURR
	}type;
private:
	map<string, base_variable_t> values;
	map<string, myclass_define_t> classes;
	multimap<string, func_value_t> funcs;
	_STD list<base_variable_t> heap_values;
};

class run_environment {
	//friend class syntatic_analyzer;
public:
	typedef sh_ptr<current_environment_t> pcurrent_env_t;
	run_environment() {
		pHEAP = allocate_sh<current_environment_t>();
		pGLOBAL_ENV = allocate_sh<current_environment_t>();
		pcurrent_env = pGLOBAL_ENV;
	}
	int add_class(const string &name, myclass_define_t &&n) {
		try { 
			pcurrent_env->classes.at(name);
		}
		catch (_STD out_of_range &) {
			return -1;
		}
		pcurrent_env->classes.emplace(name, Forward<myclass_define_t>(n));
		return 0;
	}
	int add_class_inst(myclass_instance_t && mi,bool isstatic,bool isconst) {
		base_variable_t tmp;
	}
	int add_value(const string& name, const base_variable_t &var, bool isconst, bool isstatic) {
		if (isstatic)
			return add_global_value(name, var, isconst);
		else
			return add_value(name, var, isconst);
	}
	int add_value(const string& name, const base_variable_t &var, bool isconst=false) {
		return _add_value(name, var, isconst, pcurrent_env);
	}
	int add_global_value(const string& name, const base_variable_t &var, bool isconst = false) {
		return _add_value(name, var, isconst, pGLOBAL_ENV);
	}
	int add_func(const string & name, func_value_t &func) {
		return _add_func(name, func, pcurrent_env);
	}
	int add_global_func(const string &name, func_value_t &func) {
		return _add_func(name, func, pGLOBAL_ENV);
	}
	void add_new_env(bool is_func = false, bool ordin = false)	//ordin is IF_TOKEN
	{//add new env and set pcurrent_env
		pcurrent_env_t func_env(new current_environment_t);
		func_env->last = is_func ? pcurrent_env : (pcurrent_env->last);
		func_env->outer = is_func ? pGLOBAL_ENV : pcurrent_env;
		//func_env->cir_outer = ordin ? pcurrent_env->cir_outer : pcurrent_env;
		//func_env->func_call_outer = pcurrent_env;
		if (is_func)
			func_env->type = current_environment_t::FUNC_CURR;
		else if (ordin)
			func_env->type = current_environment_t::ORDIN_CURR;
		else
			func_env->type = current_environment_t::CIR_CURR;
		pcurrent_env = func_env;
	}
	enum delete_curr_t{
		RETURN_DEL,
		JUSTONE_DEL,
		CONTINUE_DEL,
		BREAK_DEL
	};
	int delete_current_env(delete_curr_t opt)
	{//delete string &func & ptr
		//for RETURN and BREAK or CONTINUE
		//return the number of SYN.unsave()
		if (pcurrent_env == pGLOBAL_ENV) {
			pcurrent_env = pGLOBAL_ENV = nullptr;
		}
		else{
			try {
				int i = 0;
				switch (opt)
				{
				case RETURN_DEL:	//return
					while (pcurrent_env->type != current_environment_t::FUNC_CURR) {
						pcurrent_env = pcurrent_env->outer;
						i++;
					}
					pcurrent_env = pcurrent_env->last;
					i++;
					return i;
					//return 0;
				case JUSTONE_DEL:	//just one
					pcurrent_env = pcurrent_env->outer;
					return 0;
				case CONTINUE_DEL:	//continue
					while (pcurrent_env->type != current_environment_t::CIR_CURR) {
						pcurrent_env = pcurrent_env->outer;
						i++;
					}
					return i;
				case BREAK_DEL:	//break
					while (pcurrent_env->type != current_environment_t::CIR_CURR) {
						pcurrent_env = pcurrent_env->outer;
						i++;
					}
					pcurrent_env = pcurrent_env->outer;
					i++;
					return i;
				default:
					return -1;
				}
			}
			catch (_STD exception &) {
				throw _STD runtime_error("switch context error:\n memory error.");
			}
		}
		return 0;
	}
	myclass_define_t *find_class(const string &name)
	{
		return find_class(name, pcurrent_env);
	}
	myclass_define_t *find_class(const string &name,pcurrent_env_t now)
	{
		current_environment_t *penvir = now.get();
		myclass_define_t *ret = nullptr;
		do {
			try {
				ret = &(penvir->classes.at(name));
			}
			catch (_STD out_of_range&) {
				penvir = penvir->outer.get();
			}
		} while (ret == nullptr && penvir != nullptr);
		return ret;
	}
	base_variable_t *find_value(const string &name)
	{
		return _find_value_global(name, pcurrent_env);
	}
	base_variable_t *find_global_value(const string &name)
	{
		return _find_value_global(name, pGLOBAL_ENV);
	}
	func_value_t *find_func(const string &name,
		par_list_type_t &par_list)
	{
		return _find_func_global(name, par_list, pcurrent_env);
	}
	func_value_t *find_global_func(const string &name,
		par_list_type_t &par_list)
	{
		return _find_func_global(name, par_list, pGLOBAL_ENV);
	}
	pcurrent_env_t pHEAP;
	pcurrent_env_t pGLOBAL_ENV;
	pcurrent_env_t pcurrent_env;
private:
	int _add_func(const string & name, func_value_t &func, pcurrent_env_t p) {
		multimap<string, func_value_t>::iterator beg, end, now;
		beg = p->funcs.lower_bound(name);
		end = p->funcs.upper_bound(name);
		for (now = beg; now != end; ++now)
		{
			if (now->second.paras == func.paras)
			return -1;
		}
		p->funcs.insert(_STD pair<string, func_value_t>(name, func));
		return 0;
	}
	int _add_value(const string& name, const base_variable_t &var, bool isconst, pcurrent_env_t p) {
		try {
			p->values.at(name);
		}
		catch (_STD exception &) {
			base_variable_t tmp = var;
			p->values[name] = tmp;
			p->values[name].isconst = isconst;
			return 0;
		}
		return -1;	//already have name
	}
	base_variable_t *_find_value_global(const string &name, pcurrent_env_t &n)
	{
		current_environment_t *penvir = n.get();
		base_variable_t *ret = nullptr;
		do {
			ret = _find_value(name, penvir);
			penvir = penvir->outer.get();
		} while (ret == nullptr && penvir != nullptr);
		return ret;
	}
	func_value_t *_find_func_global(const string &name,
		par_list_type_t &par_list, pcurrent_env_t &n)
	{
		current_environment_t *penvir = n.get();
		func_value_t *ret = nullptr;
		do {
			ret = _find_func(name, par_list, penvir);
			penvir = penvir->outer.get();
		} while (ret == nullptr && penvir != nullptr);
		return ret;
	}
	base_variable_t *_find_value(const string &name,
		current_environment_t *penv = nullptr)
	{
		if (!penv) penv = pcurrent_env.get();
		try {
			return &(penv->values.at(name));
		}
		catch (_STD exception &) {
			return nullptr;
		}
	}
	func_value_t *_find_func(const string &name,
		par_list_type_t &par_list,
		current_environment_t *penv = nullptr)
	{
		if (!penv) penv = pcurrent_env.get();
		multimap<string, func_value_t>::iterator beg, end, now;
		beg = penv->funcs.lower_bound(name);
		end = penv->funcs.upper_bound(name);
		for (now = beg; now != end; ++now)
		{
			if (now->second.paras == par_list)
				return &(now->second);
		}
		return nullptr;
	}
};
